//------------------------------------------------------
// Menu GUI (MenuGUI-sliders.js)
//------------------------------------------------------
// Writing by Sergey Gasanov (sgiman.com) @ 2012-2013 
// Version: 2.0
//
//	ICARM (Interactive presentation C-ARM)	
//------------------------------------------------------
var guiSkin: GUISkin;

private var buttonWidth : int = 100; 
private var buttonHeight : int = 25;	
private var spacing:int = 2;

function OnGUI()
{  
	GUI.skin = guiSkin; 	 	 	    	
	
	//Help Info (UP)	
  	GUI.Label (Rect (10, 10, 800, 20), this.GetComponent("Data").HeaderSlide);
	
	// Menu Area
	GUILayout.BeginArea(Rect(10, Screen.height-buttonHeight-10, (buttonWidth+2)*6, 100));
	GUILayout.BeginHorizontal();

	// (1) Button Ineractive 
	if(GUILayout.Button("Interactive", GUILayout.Height(buttonHeight)))
	{
		Application.LoadLevel("Main");
	}

	// (2) Button Simulation
	if(GUILayout.Button("Lessons", GUILayout.Height(buttonHeight)))
	{
		Application.LoadLevel("Lessons");
	}

	// (3) Button Animation        
	if(GUILayout.Button("Animation", GUILayout.Height(buttonHeight)))
	{
		Application.LoadLevel("Anim1");
	}

	// (4) Slide-Show 
	if(GUILayout.Button("Sideshow", GUILayout.Height(buttonHeight)))
	{
		Application.LoadLevel("Slideshow");
	}

	// (5) HELP 
	if(GUILayout.Button("Help", GUILayout.Height(buttonHeight)))
	{
		Application.OpenURL ((Application.dataPath) + "./carm.rtf"); // Help File

	}

	// (6) Button FULLSCREEN        
	if(GUILayout.Button("FullScreen", GUILayout.Height(buttonHeight)))
	{
		Screen.fullScreen = !Screen.fullScreen; 
	}

	// (7) Button EXIT 
	if(GUILayout.Button("Exit", GUILayout.Height(buttonHeight)))
	{
		 Application.Quit(); 
	}

	GUILayout.EndHorizontal();
	GUILayout.EndArea();
}

