//======================================================
// Data.js
//
// Writing by Sergey Gasanov (sgiman.com) @ 2013 
// Version: 2.1
//
// ICARM (Interactive presentation C-ARM)	
//======================================================
//#pragma strict

// Var headers levels
public var HeaderInt : String;
public var HeaderSim : String; 
public var HeaderAnim : String;
public var HeaderSlide : String;

function Update () 
{
	// Init headers levels
	HeaderInt 	= "ICARM Version 2.1 (presentaion). Interactive.";
	HeaderSim 	= "ICARM Version 2.1 (presentaion). Lessons."; 
	HeaderAnim 	= "ICARM Version 2.1 (presentaion). Interactive Animation.";
	HeaderSlide = "ICARM Version 2.1 (presentaion). Slides Show.";
}
