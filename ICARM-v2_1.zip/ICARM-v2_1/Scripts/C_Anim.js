/***************************************************** 
	C_Anim.js
  
  Writing by Sergey Gasanov (sgiman.com) @ 2012,2013
	version 1.7.5

	ICARM (Interactive presentation C-ARM)	
******************************************************/

// GuiSkin
var guiSkin : GUISkin;

// Material for Highlight
var MatOrig : Material;   
var MatSel : Material;  
var MatBtnXray : Material;  
var MatBtnLiftUp : Material;  
var MatBtnLiftDown : Material;  

// Brakes
var OrbitalBrake : GameObject;			// BRAKE
var ArmPivot : GameObject;				// ANIM
var Driver_sholder_03 : GameObject; 	// MAT

var FipFlopBrake : GameObject;			// BRAKE
var FipFlop : GameObject;				// ANIM
var Driver_sholder_06 : GameObject; 	// MAT

var LArmBrake : GameObject;				// BRAKE
var LArm : GameObject;					// ANIM
var Driver_sholder_02 : GameObject;		// MAT

var HorizontalCrossBrake : GameObject;	// BRAKE
var HorizontalCrossArm : GameObject;	// ANIM
var Driver_Monitor_01  : GameObject;	// MAT	

var WigWagBrake : GameObject;			// BRAKE
var WigWag : GameObject;				// ANIM
var Driver_Monitor_02 : GameObject;		// MAT

// Wheels & Breaks
var HandleRight : GameObject;			// BREAK
var Handle_Wheel_Right : GameObject;	// MAT
var HandleLeft : GameObject;			// BREAK
var Handle_Wheel_Left : GameObject;		// MAT
var BigWheelR : GameObject;				// ANIM
var BigWheelL : GameObject;				// ANIM
var FrontWheelR  : GameObject;			// ANIM		
var FrontWheelL : GameObject;			// ANIM

// Buttons
var VerticalColumn : GameObject;		// ANIM
var UpLiftButton : GameObject;			// ANIM
var Up_Button : GameObject; 			// MAT
var DownLiftButton : GameObject;		// ANIM
var Down_Button : GameObject;			// MAT
var XrayButton : GameObject;			// ANIM
var XRay_Button1  : GameObject;			// BUTTON

// Driver_sholder_03
var Sphere_Sel_1_1 : Renderer;
var Sphere_Sel_1_2 : Renderer;

// Driver_sholder_06 
var Sphere_Sel_2_1 : Renderer;
var Sphere_Sel_2_2 : Renderer;

// Driver_sholder_02
var Sphere_Sel_3_1 : Renderer;
var Sphere_Sel_3_2 : Renderer;

// Handle_Wheel_Left
var Sphere_Sel_4_1 : Renderer;

// Handle Wheel Left
var Sphere_Sel_4_2 : Renderer;

// Driver_Monitor_02
var Sphere_Sel_5 : Renderer;

// Driver_Monitor_01
var Sphere_Sel_6 : Renderer;

// X-Ray Button 1
var Sphere_Sel_7 : Renderer;

// Up Button
// Down Button
var Sphere_Sel_8 : Renderer;

private var  b1 = false; 	// OrbitalBrake
private var  b2 = false;	// FipFlopBrake
private var  b3 = false;	// LArmBrake
private var  b4 = false;	// HorizontalCrossBrake
private var  b5 = false;	// WigWagBrake
private var  b6 = false;	// LeftWheelRotation
private var  b7 = false;	// RightWheelRotation
private var  b8 = false;	// UpLiftButton
private var  b9 = false;	// DownLiftButton
private var  b10 = false;	// XrayButton


function Start ()
{

	Sphere_Sel_1_1.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_1_2.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_2_1.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_2_2.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_3_1.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_3_2.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_4_1.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_4_2.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_5.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_6.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_7.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_8.GetComponent.<Renderer>().enabled = false;
}


function  OnGUI ()
{    	 	 	    	
	
	GUI.skin = guiSkin; // Current GUI Skin
	
	// Make a background box
	GUI.backgroundColor = new Color(1.0f, 1.0f, 1.0f, 0.5f);
	GUI.Box (new Rect (10, 510, 210, 300), "ANIMATION C-ARM:");
	GUI.backgroundColor = new Color(1.0f , 1.0f , 1.0f , 1.0f);

	GUI.contentColor = Color.yellow;
		
	b1 = GUI.Button ( new Rect(15,540,200,20), "Orbital");    
	b2 = GUI.Button ( new Rect(15,560,200,20), "Fip-Flop");    
	b3 = GUI.Button ( new Rect(15,580,200,20), "L-Arm");    
	b4 = GUI.Button ( new Rect(15,600,200,20), "Horizontal Cross");    
	b5 = GUI.Button ( new Rect(15,620,200,20), "Wig-Wag");    
	b6 = GUI.Button ( new Rect(15,640,200,20), "Right Wheel Rotation");    
	b7 = GUI.Button ( new Rect(15,660,200,20), "Left Wheel Rotation");    
	b8 = GUI.Button ( new Rect(15,680,200,20), "Up Lift");    
	b9 = GUI.Button ( new Rect(15,700,200,20), "Down Lift");    
	b10 = GUI.Button ( new Rect(15,720,200 ,20), "Xray Button");    


	// ------------ ANIMATIONS -----------	
	if (b1) // Orbital
	{
		Sphere_Sel_1_1.GetComponent.<Renderer>().enabled = true;
		Sphere_Sel_1_2.GetComponent.<Renderer>().enabled = true;
		OrbitalBrake.GetComponent.<Animation>().Play("Orbital Brake");
		ArmPivot.GetComponent.<Animation>().Play("Arm Pivot");		
		WaitAnim (ArmPivot.GetComponent.<Animation>());
	}
	
	if (b2) // Fip-Flop
	{
		Sphere_Sel_2_1.GetComponent.<Renderer>().enabled = true;
		Sphere_Sel_2_2.GetComponent.<Renderer>().enabled = true;

		FipFlopBrake.GetComponent.<Animation>().Play("Fip-Flop Brake");
		FipFlop .GetComponent.<Animation>().Play("Fip-Flop");	
		WaitAnim (FipFlop.GetComponent.<Animation>());
	}

	if (b3) // L-Arm
	{
		Sphere_Sel_3_1.GetComponent.<Renderer>().enabled = true;
		Sphere_Sel_3_2.GetComponent.<Renderer>().enabled = true;

		LArmBrake.GetComponent.<Animation>().Play("L-Arm Brake");
		LArm.GetComponent.<Animation>().Play("L-Arm");	
		WaitAnim (LArm.GetComponent.<Animation>());
	}
	
	if (b4) // Horizontal Cross Arm
	{
		Sphere_Sel_6.GetComponent.<Renderer>().enabled = true;

		HorizontalCrossBrake.GetComponent.<Animation>().Play("Hor Cross Brake");
		HorizontalCrossArm.GetComponent.<Animation>().Play("Hor Cross Arm");	
		WaitAnim (HorizontalCrossArm.GetComponent.<Animation>());
	}

	if (b5) // Wig-Wag
	{
		Sphere_Sel_5.GetComponent.<Renderer>().enabled = true;

		WigWagBrake.GetComponent.<Animation>().Play("Wig-Wag Brake");
		WigWag.GetComponent.<Animation>().Play("Wig-Wag");	
		WaitAnim (WigWag.GetComponent.<Animation>());
	}
		
	if (b6) // Right Wheel Rotation
	{
		//Handle_Wheel_Right.renderer.material = MatSel;
		Sphere_Sel_4_1.GetComponent.<Renderer>().enabled = true;

		HandleRight.GetComponent.<Animation>().Play("HandleRight Brake");
		BigWheelR.GetComponent.<Animation>().Play("BigWheelR Right");	
		FrontWheelR.GetComponent.<Animation>().Play("FrontWheelR Right");	
		WaitAnim (BigWheelR.GetComponent.<Animation>());
	}

	if (b7) // Left Wheel Rotation
	{
		//Handle_Wheel_Left.renderer.material = MatSel;
		Sphere_Sel_4_2.GetComponent.<Renderer>().enabled = true;

		HandleLeft.GetComponent.<Animation>().Play("HandleLeft Brake");
		BigWheelL.GetComponent.<Animation>().Play("BigWheelL Left");	
		FrontWheelL.GetComponent.<Animation>().Play("FrontWheelL Left");	
		WaitAnim (BigWheelL.GetComponent.<Animation>());
	}

	if (b8) // Up Lift Button
	{
		Up_Button.GetComponent.<Renderer>().material = MatSel;
		Sphere_Sel_8.GetComponent.<Renderer>().enabled = true;

		UpLiftButton.GetComponent.<Animation>().Play("UpLiftButton");
		VerticalColumn.GetComponent.<Animation>().Play("VerticalColumn Up");
		WaitAnim (VerticalColumn.GetComponent.<Animation>());
	}

	if (b9) // Down Lift Button
	{
		Down_Button.GetComponent.<Renderer>().material = MatSel;
		Sphere_Sel_8.GetComponent.<Renderer>().enabled = true;

		DownLiftButton.GetComponent.<Animation>().Play("DownLiftButton");
		VerticalColumn.GetComponent.<Animation>().Play("VerticalColumn Down");
		WaitAnim (VerticalColumn.GetComponent.<Animation>());
	}

	if (b10) // Xray Button
	{
		XRay_Button1.GetComponent.<Renderer>().material = MatSel;
		Sphere_Sel_7.GetComponent.<Renderer>().enabled = true;

		XrayButton.GetComponent.<Animation>().Play("XrayButton");
		WaitAnim (XrayButton.GetComponent.<Animation>());
	}
	
	// STOP ANIMATION 
	GUI.contentColor = Color.white;
	if (GUI.Button (new Rect (15, 780, 200, 25), "STOP"))
	{		
		OrbitalBrake.GetComponent.<Animation>().Stop("Orbital Brake");
		ArmPivot.GetComponent.<Animation>().Stop("Arm Pivot");		
		FipFlopBrake.GetComponent.<Animation>().Stop("Fip-Flop Brake");
		FipFlop.GetComponent.<Animation>().Stop("Fip-Flop");	
		LArmBrake.GetComponent.<Animation>().Stop("L-Arm Brake");
		LArm.GetComponent.<Animation>().Stop("L-Arm");	
		HorizontalCrossBrake.GetComponent.<Animation>().Stop("Hor Cross Brake");
		HorizontalCrossArm.GetComponent.<Animation>().Stop("Hor Cross Arm");	
		WigWagBrake.GetComponent.<Animation>().Stop("Wig-Wag Brake");
		WigWag.GetComponent.<Animation>().Stop("Wig-Wag");	
		UpLiftButton.GetComponent.<Animation>().Stop("UpLiftButton");
		VerticalColumn.GetComponent.<Animation>().Stop("VerticalColumn Up");
		DownLiftButton.GetComponent.<Animation>().Stop("DownLiftButton");
		VerticalColumn.GetComponent.<Animation>().Stop("VerticalColumn Down");
		HandleRight.GetComponent.<Animation>().Stop("HandleRight Brake");
		BigWheelR.GetComponent.<Animation>().Stop("BigWheelR Right");	
		BigWheelL.GetComponent.<Animation>().Stop("BigWheelL Right");	
		FrontWheelR.GetComponent.<Animation>().Stop("FrontWheelR Right");	
		FrontWheelL.GetComponent.<Animation>().Stop("FrontWheelL Right");	
		HandleLeft.GetComponent.<Animation>().Stop("HandleLeft Brake");
		BigWheelR.GetComponent.<Animation>().Stop("BigWheelR Left");	
		BigWheelL.GetComponent.<Animation>().Stop("BigWheelL Left");	
		FrontWheelR.GetComponent.<Animation>().Stop("FrontWheelR Left");	
		FrontWheelL.GetComponent.<Animation>().Stop("FrontWheelL Left");		

		Up_Button.GetComponent.<Renderer>().material = MatBtnLiftUp;
		Down_Button.GetComponent.<Renderer>().material = MatBtnLiftDown;
		XRay_Button1.GetComponent.<Renderer>().material = MatBtnXray;

		Sphere_Sel_1_1.GetComponent.<Renderer>().enabled = false;
		Sphere_Sel_1_2.GetComponent.<Renderer>().enabled = false;
		Sphere_Sel_2_1.GetComponent.<Renderer>().enabled = false;
		Sphere_Sel_2_2.GetComponent.<Renderer>().enabled = false;
		Sphere_Sel_3_1.GetComponent.<Renderer>().enabled = false;
		Sphere_Sel_3_2.GetComponent.<Renderer>().enabled = false;
		Sphere_Sel_4_1.GetComponent.<Renderer>().enabled = false;
		Sphere_Sel_4_2.GetComponent.<Renderer>().enabled = false;
		Sphere_Sel_5.GetComponent.<Renderer>().enabled = false;
		Sphere_Sel_6.GetComponent.<Renderer>().enabled = false;
		Sphere_Sel_7.GetComponent.<Renderer>().enabled = false;
		Sphere_Sel_8.GetComponent.<Renderer>().enabled = false;
	}

} 


function WaitAnim (anim: Animation) 
{

	yield WaitForSeconds (anim.GetComponent.<Animation>().clip.length);
	Up_Button.GetComponent.<Renderer>().material = MatBtnLiftUp;
	Down_Button.GetComponent.<Renderer>().material = MatBtnLiftDown;
	XRay_Button1.GetComponent.<Renderer>().material = MatBtnXray;

	Sphere_Sel_1_1.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_1_2.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_2_1.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_2_2.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_3_1.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_3_2.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_4_1.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_4_2.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_5.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_6.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_7.GetComponent.<Renderer>().enabled = false;
	Sphere_Sel_8.GetComponent.<Renderer>().enabled = false;

}



