/*************************************************************
 SelectableObject-sim.cs
 Selectable objects (Physics - Collider, Select & ToolTip)
 -------------------------------------------------------------
 Sergey Gasanov (sgiman.com) @ 2012-2013 
 Version 3.3.2
 
 ICARM (Interactive presentation C-ARM)
--------------------------------------------------------------
Only for individual objects:
		// Fip-Flop Break
		if (gameObject.name == "Driver_sholder_06") 
		
		// Orbital Brake
		if (gameObject.name == "Driver_sholder_03") 
		
		// L-Arm Brake
		if (gameObject.name == "Driver_sholder_02") 
		
		// Wig-Wag Brake
		if (gameObject.name == "Driver_Monitor_02") 

		// Horis. Cross Arm handle (no anim)		
		if (gameObject.name == "Horis. Cross Arm handle") 

		// Horis.Cross Brake
		if (gameObject.name == "Driver_Monitor_01") 

		// HandleRight Brake
		if (gameObject.name == "Handle Wheel Right") 
		
		// HandleLeft Brake
		if (gameObject.name == "Handle Wheel Left") 
*************************************************************/
using UnityEngine;
using System.Collections;

public class SelectableObject : MonoBehaviour
{
	// Brakes
	public GameObject OrbitalBrake;
	public GameObject ArmPivot;

	public GameObject FipFlopBrake;
	public GameObject FipFlop;

	public GameObject LArmBrake;
	public GameObject LArm;
	
	public GameObject HorizontalCrossBrake;
	public GameObject HorizontalCrossArm;
	
	public GameObject WigWagBrake;
	public GameObject WigWag;

	// Wheels
	public GameObject HandleRight;
	public GameObject HandleLeft;

	public GameObject BigWheelR;
	public GameObject BigWheelL;

	public GameObject FrontWheelR;
	public GameObject FrontWheelL;
	
	public Material MatOrig;  
	public Material MatSel;  

	
	//--- Window Select ---
	private Rect windowRectSel = new Rect (420, 815, 210, 85);
	
	//--- ToolTip ---
	private GUIStyle guiStyleFore;
	private GUIStyle guiStyleBack; 

	private string obj_name, part_name;
	private float x, y;
	
	public void Start(){  
		// Fore
		guiStyleFore = new GUIStyle();
		guiStyleFore.normal.textColor = Color.yellow;      
		guiStyleFore.alignment = TextAnchor.UpperCenter ;    
		guiStyleFore.wordWrap = true;    

		// Back
		guiStyleBack = new GUIStyle();    
		guiStyleBack.normal.textColor = Color.black;  
		guiStyleBack.alignment = TextAnchor.UpperCenter ;    
		guiStyleBack.wordWrap = true;
		
		// print ("START");
	} 


	// Change Color GREEN/ORIG
 	public void Update ()
	{
		if (SelectionManager.IsSelected (gameObject))
			GetComponent<Renderer>().material = MatSel;
		else 
			GetComponent<Renderer>().material = MatOrig;
	}
	
	// GUI (Object Selected & ToolTip)
	public void OnGUI ()
	{
	
		// ToolTip
		if (obj_name != "")    
		{        
			x = Event.current.mousePosition.x+70;
			y = Event.current.mousePosition.y-30;        

			GUI.Label (new Rect (x-149,y+21,300,60), obj_name, guiStyleBack);        
			GUI.Label (new Rect (x-150,y+20,300,60), obj_name, guiStyleFore);    
			
		}
		
		// If select
		obj_name = "";
		if (SelectionManager.IsSelected (gameObject))
			//windowRectSel = GUI.Window (GetInstanceID (), windowRectSel, SelectionWindow, "SELECTED:");
			windowRectSel = GUI.Window (999, windowRectSel, SelectionWindow, "SELECTED:");

	}
	

	//---------------------------------------------------------------------------------------
	// Mouse for sectect ON 
	public void OnMouseDown ()
	{
		SelectionManager.Select (gameObject, !SelectionManager.IsSelected (gameObject));
	}
	
	// Mouse for sectect OFF 
	public void OnDisable ()
	{
		SelectionManager.Deselect (gameObject);
	}
	//---------------------------------------------------------------------------------------

	// GUI (Info-Box Selected)
	void SelectionWindow (int id)
	{
		//===========================================
		//              START ANIMATION
		//===========================================
		// Orbital Brake
		if (gameObject.name == "Driver_sholder_03") 
		{
			obj_name = "Orbital Brake";
			OrbitalBrake.GetComponent<Animation>().Play("Orbital Brake");
			ArmPivot.GetComponent<Animation>().Play("Arm Pivot");
		}

		// Fip-Flop Break
		if (gameObject.name == "Driver_sholder_06") 
		{	
			obj_name = "Flip-Flop Brake";
			FipFlopBrake.GetComponent<Animation>().Play("Fip-Flop Brake");
			FipFlop.GetComponent<Animation>().Play("Fip-Flop");
		}	
			
		// L-Arm Brake
		if (gameObject.name == "Driver_sholder_02") 
		{	
			obj_name = "L-Arm Brake";
			LArmBrake.GetComponent<Animation>().Play("L-Arm Brake");
			LArm.GetComponent<Animation>().Play("L-Arm");	
		}
		
		// Wig-Wag Brake
		if (gameObject.name == "Driver_Monitor_02") 
		{
			obj_name = "Wig-Wag Brake";
			WigWagBrake.GetComponent<Animation>().Play("Wig-Wag Brake");
			WigWag.GetComponent<Animation>().Play("Wig-Wag");	
		}

		// Horis. Cross Arm handle (no anim)		
		if (gameObject.name == "Horis. Cross Arm handle") 
		{
			obj_name = "Horis.Cross Arm Рќandle";
		}

		// Horis.Cross Brake
		if (gameObject.name == "Driver_Monitor_01") 
		{
			obj_name = "Horis.Cross Brake";
			HorizontalCrossBrake.GetComponent<Animation>().Play("Hor Cross Brake");
			HorizontalCrossArm.GetComponent<Animation>().Play("Hor Cross Arm");	
		}
		
		// HandleRight Brake
		if (gameObject.name == "Handle Wheel Right") 
		{
			obj_name = "Handle Wheel Right";
			HandleRight.GetComponent<Animation>().Play("HandleRight Brake");
			BigWheelR.GetComponent<Animation>().Play("BigWheelR Right");	
			FrontWheelR.GetComponent<Animation>().Play("FrontWheelR Right");	
		}
		
		// HandleLeft Brake
		if (gameObject.name == "Handle Wheel Left") 
		{
			obj_name = "Handle Wheel Left";
			HandleLeft.GetComponent<Animation>().Play("HandleLeft Brake");
			BigWheelL.GetComponent<Animation>().Play("BigWheelL Left");	
			FrontWheelL.GetComponent<Animation>().Play("FrontWheelL Left");	
		}	
		
		GUILayout.Box (obj_name); // Input Select Object Name 

		//===================================================
		//                   DESELECT 
		//===================================================
		if (GUI.Button (new Rect (10, 50, 190, 25), "Stop")) 
		{
			SelectionManager.Deselect (gameObject); // Deselection Object
		}

		GUI.DragWindow ();
	}

}// End SelectableObject


//=======================================================================================
//                            CLASS SelectionManager
//=======================================================================================
public class SelectionManager
{
	private static GameObject s_ActiveSelection;
	
	// - ActiveSelection - 
	public static GameObject ActiveSelection
	{
		get
		{
			return s_ActiveSelection;
		}
		set
		{
			s_ActiveSelection = value;
		}
	}
	
	// - Select -
	public static void Select (GameObject gameObject, bool selectionValue)
	{
		if (selectionValue)
		{
			Select (gameObject);
		}
		else
		{
			Deselect (gameObject);
		}
	}
	
	// - Select -
	public static void Select (GameObject gameObject)
	{
		ActiveSelection = gameObject;
	}
	
	// - Deselect -
	public static void Deselect (GameObject gameObject)
	{
		if (ActiveSelection == gameObject)
		{
			ActiveSelection = null;
		}
	}
	
	// - IsSelected -
	public static bool IsSelected (GameObject gameObject)
	{
		return ActiveSelection == gameObject;
	}

} // End Class SelectionManager

