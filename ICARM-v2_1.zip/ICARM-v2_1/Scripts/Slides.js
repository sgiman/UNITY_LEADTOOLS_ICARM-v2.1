/***************************************************** 
	slides.cs
  
  Writing by Sergey Gasanov (sgiman.com) @ 2012-2013
	version 2.0

  ICARM (Interactive presentaion C-ARM)
*******************************************************/

var frames : Texture[];

private var frame= 0;
private var sld  = false;

var h : int = 960; 
var w : int = 720;

private var x : int;
private var y : int;


function Start ()
{
	frame = 0;
}


function OnGUI()
{
  	if(!frames[frame]){ 
  		Debug.LogError("Assign a Texture in the inspector.");            
  		return;
  	}	
	
	x = Screen.width/2 - h/2; 
	y = Screen.height/2 - w/2;
	
	GUI.DrawTexture(Rect(x, y, h, w), frames[frame]);
	//GUI.DrawTexture(Rect(0,0,Screen.width,Screen.height),frames[frame]);

	// Botton FIRST 
	if (GUI.Button (Rect (700, Screen.height-35, 100, 25), "First >>"))
	{
        frame = 0;
	}

	// Botton NEXT 
	if (GUI.Button (Rect (810, Screen.height-35, 100, 25), "Next >"))
	if (frame <= frames.Length)		
         frame++;
	if (frame == frames.Length)
         frame = 0;

	// Botton PREV 
	if (GUI.Button (Rect (920, Screen.height-35, 100, 25), "Prev <"))
	if (frame <= frames.Length)		
         frame--;
	if (frame <= 0)
         frame = 0;

	// Botton LAST 
	if (GUI.Button (Rect (1030, Screen.height-35, 100, 25), "<< Last"))
	{
        frame = 13;
	}
   	GUI.Label (Rect (1160, Screen.height-30, 100, 25), frame.ToString());
	print(frames.Length);

}

