//==========================================
// C_Breakes_anim.js (Animation)
//
// Writing Sergey Gasanov (sgiman.com) @ 2013
// version 2.5.3
//
// ICARM (Interactive presentation C-ARM)	
//-----------------------------------------
// Objects:
//-----------------------------------------
// C_FlipFlopMotion
// C_HorizontalExtension
// C_LArmRotation
// C_MotionOrbital
// C_VerticalLift
// C_WigWagMotion
//========================================= 
// Vector3.up,down,right,left,forward 
//-----------------------------------------
// up - rotate Y axis 
// down - rotate X axis
// right,left - rotate YZ axis (diagonal)
// vector3.forward - rotate Z axis  
//=========================================

var speedRot = 10.0;

// C-ARM MOVE
var speed = 1.0;
//var aLeft: Texture2D; 
//var aRight: Texture2D; 

// GuiSkin
var guiSkin: GUISkin;

// CENTERS
var CamCenter: GameObject;  // Center Cameras (AP/LAT)
var LineCenter: GameObject; // Centers Lines X-RAY

// C_FlipFlopMotion
var FlipFlop : GameObject;
private var FlipFlopAngX : float;

// C_HorizontalExtension
var HorExt : Transform;
private var HorExtVal : float;
private var v_hx : float;
private var t_hor : float;

// C_LArmRotation
var LArmRotation : GameObject;
private var LArmAngleX : float;

// C_MotionOrbital
var MotionOrbital : GameObject;
private var MotionOrbitalAngleZ : float;

// C_VerticalLift
var VerticalLift : Transform;
private var VerticalLiftVal : float;
private var v_hy : float;
private var t_vert : float;

// C_WigWagMotion
var WigWag : GameObject;
var arrowLeft: Texture2D; 
var arrowRight: Texture2D; 
var rotateSpeed = 10;		
private var curAngle : float = 0;

// Wheels & Breaks
var Big_Wheel_R_CTRL : GameObject;
var Big_Wheel_L_CTRL : GameObject;
var Front_Wheel_R : GameObject;
var Front_Wheel_L : GameObject;
var Handle_Wheel_Left_CTRL : GameObject;
var Handle_Wheel_Right_CTRL : GameObject;

// Sevices on-off
var carm : GameObject;  

private var ang_c_arm : float = 0;  
private var first : boolean = false;
private var second : boolean = false;
private var windowRect_carm_mov : Rect = Rect (5, 350, 210, 85);

// Buttons GUIStyle's
public var ARROW_LEFT_BUTTON: GUIStyle;
public var ARROW_RIGHT_BUTTON: GUIStyle;


function Start () 
{
	FlipFlopAngX = 0;
	HorExtVal = -3.368088;
	LArmAngleX = 0;
	MotionOrbitalAngleZ = 61;
	VerticalLiftVal = 4.477582;
	TableY = 9.012033;
}	


function Update () 
{

// (1) MotionOrbital Rotate Z
// (2) HorizontalExtension Mov X
// (3) VerticalLift Mov Y
// (4) LArmRotation Rotate Z
// (5) FlipFlopMotion Rotate X
// (7) RESET

}


function OnGUI() {
	
	GUI.skin = guiSkin; // Current GUI Skin

	// C-ARM MOVE
	windowRect_carm_mov = GUI.Window (1, windowRect_carm_mov, carm_move, "C-ARM MOVE:"); 

	//=================================
	// Make a background box "SERVCE"
	//=================================
	GUI.backgroundColor = Color(1.0f ,1.0f , 1.0f , 0.5f);
	GUI.Box (Rect (5,40,210,300), "C-ARM CONTROL:");
	GUI.backgroundColor = Color(1.0f , 1.0f , 1.0f , 1.0f);

	// (1) Orbital Motion (Angle Z) -- 
	GUI.Label(Rect(10, 60, 200, 30), "Orbital Motion: ");
	MotionOrbitalAngleZ = GUI.HorizontalSlider (Rect (10, 80, 200, 30), MotionOrbitalAngleZ, -61, 61);
	MotionOrbital.transform.localEulerAngles = new Vector3(transform.rotation.x, transform.rotation.y, MotionOrbitalAngleZ);
	CamCenter.transform.localEulerAngles = new Vector3(CamCenter.transform.rotation.x, CamCenter.transform.rotation.y, MotionOrbitalAngleZ-90);
	LineCenter.transform.localEulerAngles = new Vector3(LineCenter.transform.rotation.x, LineCenter.transform.rotation.y, MotionOrbitalAngleZ-90);
	
	// (2) Vertical Lift
	GUI.Label(Rect(10, 100, 200, 30), "Vertical Lift: ");
	VerticalLiftVal = GUI.HorizontalSlider (Rect (10, 120, 200, 30), VerticalLiftVal, 4.477582, 8.440429);
	v_hy = VerticalLiftVal;
	t_vert = Mathf.Round(v_hy * 100.0) / 100.0;
	VerticalLift.transform.localPosition.y = v_hy;

	// (3) Horizontal Extension (Y)
	GUI.Label(Rect(10, 140, 200, 30), "Horizontal Extension: ");
	HorExtVal = GUI.HorizontalSlider (Rect (10, 160, 200, 30), HorExtVal, -3.368088, -0.7925819);
	v_hx = HorExtVal;
	t_hor = Mathf.Round((v_hx+3.368088) * 100.0) / 100.0;
	HorExt.transform.localPosition.x = v_hx;

	// (4) Flip FlopMotion (Angle X)
	GUI.Label(Rect(10, 180, 200, 30), "Flip-Flop Motion: ");
	FlipFlopAngX = GUI.HorizontalSlider (Rect (10, 200, 200, 30), FlipFlopAngX, -45, 45);
	FlipFlop.transform.localEulerAngles = new Vector3(FlipFlopAngX, transform.rotation.y, transform.rotation.z);

	// (5) L-ARM Rotaton (Angle Z)
	GUI.Label(Rect(10, 220, 200, 30), "L-ARM Rotaton: ");
	LArmAngleX = GUI.HorizontalSlider (Rect (10, 240, 200, 30), LArmAngleX, -60, 60);
  	LArmRotation.transform.localEulerAngles = new Vector3(LArmAngleX, transform.rotation.y, transform.rotation.z);


	// (6) Button RESET 
	if (GUI.Button (Rect (10, 310, 200, 25), "Reset")) 
	{
		FlipFlopAngX = 0;
		HorExtVal = -3.368088;
		LArmAngleX = 0;
		MotionOrbitalAngleZ = 61;
		VerticalLiftVal = 4.477582;
		TableY = 9.012033;
	}

 	//----------------------- 
 	//--- Wig-Wag Motion ---
	//----------------------
	GUI.Label (Rect (60, 440, 200, 25), "Wig-Wag Motion"); 

	if(GUI.RepeatButton (Rect (60,460,35,35), "", ARROW_LEFT_BUTTON))
	{
   		curAngle = rotateSpeed * Time.deltaTime;
   		WigWag.transform.Rotate (Vector3.down, curAngle);
	}
		
	if(GUI.RepeatButton (Rect (120,460,35,35), "", ARROW_RIGHT_BUTTON))
	{
   		curAngle = rotateSpeed * Time.deltaTime;
   		WigWag.transform.Rotate (Vector3.up, curAngle);
	}
		
}


//================================================
//                  Window C-ARM moving
//================================================  
function carm_move (windowID : int) {
    // Move C-ARM Forward/Back    
	GUI.Label (Rect (10, 20 ,200, 25), "Forward / Back"); 
	if(GUI.RepeatButton (Rect (10, 40, 35, 35), "", ARROW_LEFT_BUTTON))
	{
		carm.transform.Translate(Vector3.right * Time.deltaTime * speed);	
	}
	if(GUI.RepeatButton (Rect (50, 40, 35, 35), "", ARROW_RIGHT_BUTTON))
	{
		carm.transform.Translate(Vector3.left * Time.deltaTime * speed);
	}

    // Move C-ARM Right/Left    
	GUI.Label (Rect (120, 20 ,200, 25), "Left / Right"); 
	if(GUI.RepeatButton (Rect (120, 40, 35, 35), "", ARROW_LEFT_BUTTON))
	{
		carm.transform.Translate(Vector3.forward * Time.deltaTime * speed);	
	}
	if(GUI.RepeatButton (Rect (160, 40, 35, 35), "", ARROW_RIGHT_BUTTON))
	{
		carm.transform.Translate(Vector3.back * Time.deltaTime * speed);
	}
	
	GUI.DragWindow (Rect (0,0,10000,10000));
}


