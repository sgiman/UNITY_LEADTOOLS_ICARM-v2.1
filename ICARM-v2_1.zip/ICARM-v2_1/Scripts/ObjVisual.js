/******************************************************* 
  ObjVisual.js
  Objects Visual (for main)
--------------------------------------------------------	
  Writing by Sergey Gasanov (sgiman.com) @ 2012-2013
  Version: 1.2

  ICARM (Interactive presentation C-ARM)	
*******************************************************/
var guiSkin: GUISkin;		
var carm: GameObject; 
var CamCenter: GameObject;  // Center Cameras (AP/LAT)

var hSensitivity = 0.025;
var vSensitivity = 0.025;

// Cameras
var cam1 : Camera; // MAIN
var cam2 : Camera; // LAT 

// Spine
var C1 : Renderer;
var C2 : Renderer;
var C3 : Renderer;
var C4 : Renderer;
var C5 : Renderer;
var C6 : Renderer;
var C7 : Renderer;

var disc_L1 : Renderer;
var disc_L2 : Renderer;
var disc_L3 : Renderer;
var disc_L4 : Renderer;
var disc_L5 : Renderer;

var disc_C1_L : Renderer;
var disc_C1_R : Renderer;
var disc_C2 : Renderer;
var disc_C3 : Renderer;
var disc_C4 : Renderer;
var disc_C5 : Renderer;
var disc_C6 : Renderer;
var disc_C7 : Renderer;

var disc_T1 : Renderer;
var disc_T2 : Renderer;
var disc_T3 : Renderer;
var disc_T4 : Renderer;
var disc_T5 : Renderer;
var disc_T6 : Renderer;
var disc_T7 : Renderer;
var disc_T8 : Renderer;
var disc_T9 : Renderer;
var disc_T10 : Renderer;
var disc_T11 : Renderer;
var disc_T12 : Renderer;

var L1 : Renderer;
var L2 : Renderer;
var L3 : Renderer;
var L4 : Renderer;
var L5 : Renderer;

var T1 : Renderer;
var T2 : Renderer;
var T3 : Renderer;
var T4 : Renderer;
var T5 : Renderer;
var T6 : Renderer;
var T7 : Renderer;
var T8 : Renderer;
var T9 : Renderer;
var T10 : Renderer;
var T11 : Renderer;
var T12 : Renderer;
var sacrum : Renderer;

var Nervers1 : Renderer;
var Nervers2 : Renderer;

var matDisk : Material;			// DISK
var matVert : Material;			// VERT
var matXray : Material; 		// X-RAY
var matXray2 : Material; 		// X-RAY

var MainMaxIs : boolean = false;		// Maximize MAIN view
var LatMaxIs : boolean = false;		// Maximize LAT view


private var hSliderZoom_lat : int = 35;	// Zoom LAT (default min)

// OFF/ON (MAIN WINDOW)
private var ext1 : boolean = true;	// C-ARM
private var ext2 : boolean = false;	// Table Jackson
private var ext3 : boolean = false;	// OEC Tower
private var ext4 : boolean = true;	// Body
private var ext5 : boolean = true;	// Spine
private var ext6 : boolean = true;	// Nerves

// Make the contents of the window (Patient)
private var nbtn : int = 1;
private var str : String[] = ["Real", "X-Ray"];

// ON-OFF (LAT)
private var lat_ext1 : boolean = true;	// X-ray
private var lat_ext2 : boolean = false;	// Negative
private var lat_ext3 : boolean = false;	// Nerves

// CORRECT (Xray material)
private var hSliderRim : float; 				// Bright (Rim 1-2) 
private var hSliderInside : float;				// Contrast (Inside 0-1)
private var hSliderContrast_lat : float = 0.0f; // Contrast 

// Booleans
private var cor_ext : boolean = false;		// Correct Options
private var BodyTransIs : boolean = false;	// Flasg Body Transparent
private var neg : boolean = false; 			// Negative for MAXIMIZE LAT	
private var PosLatCam : Vector3;
private var RotLatCam : Vector3;

// Rectangles
private var windowRectBright : Rect = Rect (660, 750, 220, 150);	// Window Bight "LAT"
private var windowRectPatinet : Rect = Rect (5, 500, 210, 60); 

private var RectMainMin : Rect = Rect (Screen.width/2-100, 10, 36, 36);	// RECTANGLE MAX MAIN
private var RectMainMax : Rect = Rect (Screen.width-110, 10, 36, 36);	// RECTANGLE MIN MAIN
private var RectMain : Rect;
private var RectLatReset : Rect = Rect (Screen.width-155, 10, 36, 36);	// Reset LAT

// Buttons GUIStyle's
public var NAV_WIN_MAX_MIN: GUIStyle;
public var NAV_WIN_RESET_BUTTON: GUIStyle;

// Brithess X-Ray
private var xRim : float = 0.2;
private var xInside : float = 0.15 ;


//************************* 
//         START 
//*************************
function Start () 
{
	// Brightness X-Ray Spine
	SpineXraySet (xRim, xInside);	// Sart Set X-Ray for Spine  - SpineXraySet(Rim, Inside)    
	hSliderRim = xRim; 				// Bright (Rim 1-2) 
	hSliderInside = xInside;		// Bright (Inside 0-1)
	
	// Defalult camera parameters
	hSliderZoom_lat = 15;			// FOV LAT
	
	cam1.cullingMask |= (1 << 9);	// On Layer "Body"
	cam1.cullingMask &= ~(1 << 18);	// Off Layer "BodyT"
	cam1.cullingMask |= (1 << 9);	// On Layer "SpineR"
	cam1.cullingMask &= ~(1 << 17);	// Off Layer "Nerve"

	cam2.GetComponent("GrayscaleEffect").enabled = false;	// LAT Nagative = OFF

   	// Save Camera LAT position
	PosLatCam = cam2.transform.localPosition;
	
	cam1.main.enabled = true;		// MAIN
   	cam2.enabled = false;			// LAT	

	// Size cameras MAIN & LAT (X,Y,W,H) 
	cam1.rect = new Rect(0, 0, 0.5, 1);			// MAIN RECT
	cam2.rect = new Rect(0.5, 0, 0.5, 1);		// LAT RECT

}

//************************* 
//	        OnGUI 
//*************************
function OnGUI()
{   	 	 	    	
	GUI.skin = guiSkin;
 
	//-------------- Window PATIENT (Body/X-Ray) -----------------
	if (!LatMaxIs)
		windowRectPatinet = GUI.Window (0, windowRectPatinet, WinPatient, "BODY PATIENT:");
    
    // OFFSET XY (toggle scripts)
   	if (Input.mousePosition.x > Screen.width/2)
	{
   		if (!LatMaxIs)
   		{
   			cam1.GetComponent("maxCamera").enabled = false; // Script maxCamera.cs = OFF (Main Camera) 
			PanCamCarm (); // Dragging C-ARM view
		}	
	}
	else
		cam1.GetComponent("maxCamera").enabled = true; // Script maxCamera.cs = OFF (Main Camera) 
	
	if (LatMaxIs)
	{
		cam1.GetComponent("maxCamera").enabled = false; // Script maxCamera.cs = OFF (Main Camera) 
		PanCamCarm (); // Dragging C-ARM view
	} 
	
	HideObjectsMainView (); // On-Off objects for MAIN view 
	MainInit(); 			// Init MAIN view
	LatInit();				// Init LAT view

	//-----------------------------------------------------------------------
	//                          MINIMIZE-MAXIMIZE
	//-----------------------------------------------------------------------
	if (!MainMaxIs && !LatMaxIs)
	{
		MainMaxIs = GUI.Toggle (RectMainMin, MainMaxIs, "", NAV_WIN_MAX_MIN);	// BTN ICON MAX-MIN for MAIN view
		cam1.main.enabled = true;				// MAIN ON
   		cam2.enabled = true;					// LAT ON
		cam1.rect = new Rect(0, 0, 0.5, 1);		// Set the MAIN camera back to taking up the 1/2 screen
		cam2.rect = new Rect(0.5, 0, 0.5, 1);	// LAT RECT
		GUI.Label (Rect (Screen.width/2-50, 10, 200, 20), "MAIN");
	}
	
	if (MainMaxIs && !LatMaxIs) 	
	{
		MainMaxIs = GUI.Toggle (RectMainMax, MainMaxIs, "", NAV_WIN_MAX_MIN);	// BTN ICON MAX-MIN for MAIN view
   		cam1.main.enabled = true;				// MAIN ON
   		cam2.enabled = false;					// LAT OFF
		cam1.main.rect = new Rect(0, 0, 1, 1);	// Set the MAIN camera back to taking up the full screen
		GUI.Label (Rect (Screen.width-50, 10, 200, 20), "MAIN");
		GUI.Label (Rect (Screen.width-450, Screen.height-25, 500, 20), "Use the navigation camera buttons mouse (Wheel, Middle BTN, Right BTN)");
	}
			
	if (LatMaxIs && !MainMaxIs)
	{
		LatMaxIs = GUI.Toggle (RectMainMax, LatMaxIs, "", NAV_WIN_MAX_MIN);		// BTN ICON MAX-MIN for LAT view	
	}

	if (!LatMaxIs && !MainMaxIs)
	{
		LatMaxIs = GUI.Toggle (RectMainMax, LatMaxIs, "", NAV_WIN_MAX_MIN);		// BTN ICON MAX-MIN for LAT view	
	}
	
	if (!MainMaxIs)
		GUI.Label (Rect (Screen.width-190, Screen.height-25, 200, 20), "Right Mouse Button: Dragging");
	
  	//-------------------------- 
  	//  CAMERA LAT (cam2)
	//--------------------------
	if (LatMaxIs)
	{ 
   		cam1.main.enabled = false;				// MAIN OFF
		cam2.rect = new Rect(0, 0, 1, 1);		// LAT RECT
	}
	else
	{
   		cam1.main.enabled = true;				// MAIN OFF
		cam2.rect = new Rect(0.5, 0, 0.5, 1);	// LAT RECT
	}	

	// Button "RESET C-ARM VIEW" 
	if (!MainMaxIs)
	if (GUI.Button (RectLatReset, "", NAV_WIN_RESET_BUTTON)) 
	{
		cam2.transform.localPosition = PosLatCam;
		hSliderZoom_lat = 15;
	}

	//------------------------------------------------------------------------------------------
	//                                 S E R V I C E S
	//------------------------------------------------------------------------------------------
	// Button "RESET ALL" (main) 
	GUI.contentColor = Color.white;
	if (GUI.Button (Rect (650, Screen.height-35, 100, 25), "Reset All")) 
	{
		Application.LoadLevel("main");
	}

	// Window "BRIGHTNESS" OPTIONS
	if (neg && LatMaxIs) 
		GUI.contentColor = Color.black;
	else 	
		GUI.contentColor = Color.green;
	
	cor_ext = GUI.Toggle (Rect (10, 840, 180, 20), cor_ext, " Brightness X-Ray spine");    
	GUI.enabled = true;        
	if(cor_ext) windowRectBright = GUI.Window (5, windowRectBright, WinBrightness, "Brightness X-Ray spine:");    
	GUI.contentColor = Color.white;

} 
//********************************** END OnGUI() ****************************************


//================================= 
//         Window Patients
//=================================
function WinPatient (windowID : int) 
{    
	nbtn = GUI.SelectionGrid (Rect (10, 20, 180, 30), nbtn, str, 2);
	if(nbtn == 0) BodyTransIs = false;	// Patient Real	
	if(nbtn == 1) BodyTransIs = true;	// Transparent Patient
}


//================================== 
//       HIDE OBJECTS (MAIN) 
//================================== 
function HideObjectsMainView () 
{    
	if (neg && LatMaxIs) 
		GUI.contentColor = Color.black;
	else 	
		GUI.contentColor = Color.white;
	
	// Make a background box
	GUI.backgroundColor = Color(1.0f ,1.0f , 1.0f , 0.5f);
	GUI.Box (Rect (5, 575, 210, 200), "ON/OFF:");
	GUI.backgroundColor = Color(1.0f , 1.0f , 1.0f , 1.0f);

	// HIDE (ON / OFF)
	if (!LatMaxIs)
	{
		GUI.contentColor = Color.white;       
		ext1 = GUI.Toggle (Rect (10, 600, 180, 20), ext1, " C-ARM");    
		ext2 = GUI.Toggle (Rect (10, 620, 180, 20), ext2, " TABLE");    
		ext3 = GUI.Toggle (Rect (10, 640, 180, 20), ext3, " TOWER");    
		ext4 = GUI.Toggle (Rect (10, 680, 180, 20), ext4, " BODY");    
		ext5 = GUI.Toggle (Rect (10, 700, 180, 20), ext5, " SPINE");    
		ext6 = GUI.Toggle (Rect (10, 720, 180, 20), ext6, " NERVES");    
		GUI.enabled = true;        
	}
	
	// C-ARM (10)
	if(ext1) 
		cam1.cullingMask |= (1 << 10); // ON
	else 
		cam1.cullingMask &= ~(1 << 10); // OFF
	
	// TABLE (14)
	if(ext2) 
		cam1.cullingMask |= (1 << 14); // ON
	else
		cam1.cullingMask &= ~(1 << 14); // OFF

	// TOWER (15)
	if(ext3) 
		cam1.cullingMask |= (1 << 15); // ON
	else
		cam1.cullingMask &= ~(1 << 15); // OFF

	//--------------------- Body ----------------------------
	// BODY REAL (9,18)
	if(ext4 && !BodyTransIs) 
	{ 
		cam1.cullingMask |= (1 << 9); 	// ON Layer "Body"
		cam1.cullingMask &= ~(1 << 18);	// Off Layer "BodyT"
	}
	// BODY X-RAY (9,18)
	if(ext4 && BodyTransIs) 
	{ 
		cam1.cullingMask |= (1 << 18); 	// ON Layer "BodyT"
		cam1.cullingMask &= ~(1 << 9);	// Off Layer "Body"
	}
	// BODY REAL OFF (9,18)
	if(!ext4 && !BodyTransIs) 
	{ 
		cam1.cullingMask &= ~(1 << 9);	// Off Layer "Body"
		cam1.cullingMask &= ~(1 << 18);	// Off Layer "BodyT"
	}
	// BODY X-RAY & REAL OFF (9,18)
	if(!ext4 && BodyTransIs) 
	{ 
		cam1.cullingMask &= ~(1 << 9);	// Off Layer "Body"
		cam1.cullingMask &= ~(1 << 18);	// Off Layer "BodyT"
	}
	//-------------------------------------------------------

	// SPINE REAL (8,13)
	if(ext5)
	{ 
		cam1.cullingMask |= (1 << 8); 	// ON REAL
		cam1.cullingMask &= ~(1 << 13); // OFF XRAY
	}
	else
	{
		cam1.cullingMask &= ~(1 << 8);	// OFF REAL
		cam1.cullingMask &= ~(1 << 13); // OFF XRAY
	}
	// NERVES REAL (17,19)
	if(ext6) 
	{
		cam1.cullingMask |= (1 << 17);	// ON REAL
		cam1.cullingMask &= ~(1 << 19); // OFF XRAY
	}
	else
	{
		cam1.cullingMask &= ~(1 << 17); // OFF REAL
		cam1.cullingMask &= ~(1 << 19); // OFF XRAY
	}

}


//==================================== 
//  Camera PAN (dragging)
//====================================
function PanCamCarm ()
{
	h = (-1) * Input.GetAxis("Mouse X"); //The horizontal movement - could use "Horizontal"
	v = (-1) * Input.GetAxis("Mouse Y"); //The vertical movement - could use "Vertical"

	if (Input.GetMouseButton(1))
	{		
		cam2.transform.Translate(Vector3.right * h * hSensitivity); //truck = horizontal movement
		cam2.transform.Translate(Vector3.up * v * vSensitivity);   //pedestal = vertical movement
	}
}


//==================================== 
//  MAIN View Init 
//====================================
function MainInit ()
{
    cam1.enabled = true; 	// MAIN
   	cam2.enabled = false; 	// LAT
}


//==================================== 
//  LAT View Init 
//====================================
function LatInit ()
{
	cam1.main.rect = new Rect(0.5, 0, 0.5, 1);	//set the MAIN camera back to taking up the 1/2 screen (LEFT)	
	cam2.main.rect = new Rect(0, 0, 0.499, 1);	//set the LAT camera back to taking up the 1/2 screen (RIGHT)	
	cam1.enabled = true;	// MAIN
    cam2.enabled = true;	// LAT	

	if (!MainMaxIs)
	{
		GUI.contentColor = Color.red;
		GUI.Label (Rect (Screen.width-60, 10, 200, 20), "C-ARM"); // Label window C-ARM 
	}
	
	if (lat_ext2) // if Negative
		GUI.contentColor = Color.black;
	else	 
		GUI.contentColor = Color.white; 
		
	if (!MainMaxIs)
	{
		// ZOOM LAT 
		GUI.Label(Rect(Screen.width-220, 45, 200, 30), "ZOOM: ");	// Label ZOOM for window C-ARM 
		hSliderZoom_lat = GUI.HorizontalSlider (Rect (Screen.width-220, 65, 200, 30), hSliderZoom_lat, 35,10);
		cam2.fieldOfView = hSliderZoom_lat;

		// CONTRAST LAT (View LAT)
		GUI.Label(Rect(Screen.width-220, 85, 200, 30), "CONTRAST: ");  
		hSliderContrast_lat = GUI.HorizontalSlider (Rect (Screen.width-220, 105, 200, 30), hSliderContrast_lat, 0, 3);
		CE = cam2.GetComponent("ContrastEnhance"); // Script ContrastEnhance for camera LAT 
		CE.intensity = hSliderContrast_lat;

		//--------------------------- 
		//  ON-OFF LAT
		//---------------------------
		if (LatMaxIs)
		{
			lat_ext1 = GUI.Toggle (Rect (10, 600, 180, 20), lat_ext1,  " X-Ray");    
			lat_ext2 = GUI.Toggle (Rect (10, 620, 180, 20), lat_ext2,  " Negative");
			lat_ext3 = GUI.Toggle (Rect (10, 640, 180, 20), lat_ext3, " Nerves");
    		GUI.enabled = true;
		}
		else
		{
			lat_ext1 = GUI.Toggle (Rect (Screen.width/2+20, 20, 180, 20), lat_ext1,  " X-Ray");    
			lat_ext2 = GUI.Toggle (Rect (Screen.width/2+20, 40, 180, 20), lat_ext2,  " Negative");
			lat_ext3 = GUI.Toggle (Rect (Screen.width/2+20, 60, 180, 20), lat_ext3, " Nerves");
    		GUI.enabled = true;
    	}        
	}// -- end if --
	
	// X-Ray
	if (lat_ext1) 
	{	
		cam2.cullingMask |= (1 << 13);	// ON Layer "SpineX"
		cam2.cullingMask &= ~(1 << 8);	// OFF Layer "SpineR"
	}	
	else
	{
		cam2.cullingMask &= ~(1 << 13);	// OFF Layer "SpineX"
		cam2.cullingMask |= (1 << 8);	// ON Layer "SpineR"
	}
		
	// Negative LAT
	if (lat_ext2)
	{
		cam2.GetComponent("GrayscaleEffect").enabled = true;	// LAT Nagative = ON
		neg = true;
	}
	else
	{
		cam2.GetComponent("GrayscaleEffect").enabled = false;	// LAT Nagative = OFF
		neg = false;
	}
	
	// Nerves
	if (lat_ext3)
	{ 
		cam2.cullingMask |= (1 << 19);	// ON Layer "NervesX"
		if (lat_ext1) 
		{
			cam2.cullingMask |= (1 << 19);	// ON Layer "NervesX"
			cam2.cullingMask &= ~(1 << 17);	// OFF Layer "NervesR"
		}
		else
		{
			cam2.cullingMask |= (1 << 17);	// ON Layer "NervesR"
			cam2.cullingMask &= ~(1 << 19);	// OFF Layer "NervesX"
		}	
	}	
	else
	{
		cam2.cullingMask &= ~(1 << 19);	// OFF Layer "NervesX"
		cam2.cullingMask &= ~(1 << 17);	// OFF Layer "NervesR"
	}

}


//================================== 
//     Window Brightess X-RAY
//================================== 
function WinBrightness (windowID : int) 
{    
	GUI.Label(Rect(10, 20, 200, 30), "RIM: ");		// Rim X-RAY
	GUI.Label(Rect(10, 60, 200, 30), "INSIDE: ");	// Inside X-Ray
	
	hSliderRim = GUI.HorizontalSlider (Rect (10, 40, 200, 30), hSliderRim, 0, 2);		// RIM CTRL
	hSliderInside = GUI.HorizontalSlider (Rect (10, 80, 200, 30), hSliderInside, 0, 1);	// INSIDE CTRL
	SpineXraySet (hSliderRim, hSliderInside); // Set X-Ray for spine 
	
	// Button "Reset" 
	if (GUI.Button (Rect (10, 110, 200, 25), "Reset")) 
	{
		hSliderRim = xRim;
		hSliderInside = xInside;
	}

	GUI.DragWindow (Rect (0,0,10000,10000));
}


//================================== 
//     Set X-Ray for spine 
//================================== 
function SpineXraySet (vR : float, vI: float) 
{
	// BRITNESS SPINE (Rim)
	C1.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	C3.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	C3.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	C4.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	C5.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	C6.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	C7.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );

	disc_L1.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_L2.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_L3.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_L4.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_L5.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );

	disc_C1_L.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_C1_R.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_C2.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_C3.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_C4.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_C5.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_C6.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_C7.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );

	disc_T1.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_T2.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_T3.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_T4.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_T5.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_T6.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_T7.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_T8.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_T9.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_T10.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_T11.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_T12.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_L1.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_L2.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_L3.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_L4.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	disc_L5.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );

	L1.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	L2.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	L3.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	L4.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	L5.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );

	T1.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	T2.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	T3.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	T4.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	T5.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	T6.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	T7.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	T8.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	T9.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	T10.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	T11.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	T12.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );
	sacrum.GetComponent.<Renderer>().material.SetFloat( "_Rim", vR );

	// CONTRAST SPINE (Inside)
	C1.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	C3.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	C3.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	C4.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	C5.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	C6.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	C7.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );

	disc_L1.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_L2.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_L3.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_L4.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_L5.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );

	disc_C1_L.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_C1_R.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_C2.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_C3.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_C4.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_C5.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_C6.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_C7.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );

	disc_T1.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_T2.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_T3.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_T4.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_T5.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_T6.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_T7.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_T8.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_T9.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_T10.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_T11.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	disc_T12.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );

	L1.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	L2.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	L3.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	L4.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	L5.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );

	T1.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	T2.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	T3.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	T4.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	T5.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	T6.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	T7.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	T8.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	T9.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	T10.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	T11.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	T12.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );
	sacrum.GetComponent.<Renderer>().material.SetFloat( "_Inside", vI );

}


/* Spine full & nerves
C1
C2
C3
C4
C5
C6
C7
disc_L1
disc_L2
disc_L3
disc_L4
disc_L5
disc_C1_L
disc_C1_R
disc_C2
disc_C3
disc_C4
disc_C5
disc_C6
disc_C7
disc_T1
disc_T2
disc_T3
disc_T4
disc_T5
disc_T6
disc_T7
disc_T8
disc_T9
disc_T10
disc_T11
disc_T12
L1
L2
L3
L4
L5
T1
T2
T3
T4
T5
T6
T7
T8
T9
T10
T11
T12
sacrum
*/