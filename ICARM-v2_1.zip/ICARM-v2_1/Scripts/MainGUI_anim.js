//-------------------------------------------------------
// Menu GUI Animation 
// (MenuGUI-Anim.js)
//-------------------------------------------------------
// Writing by Sergey Gasanov (sgiman.com) @ 2012-2013
// Version: 2.0
//
// ICARM (Interactive presentation C-ARM)	
//-------------------------------------------------------
//GuiSkin
var guiSkin: GUISkin;		

private var buttonWidth : int = 100; 
private var buttonHeight : int = 25;	
private var spacing : int = 2;


function OnGUI()
{   	 	 	    	
	GUI.skin = guiSkin;
	GUI.Label (Rect (10, 10, 900, 20), this.GetComponent("Data").HeaderAnim); 	// HEADER
	GUI.Label (Rect (Screen.width-80, Screen.height-20, 200, 20), "ANIMATION");	// LABEL

	//=============================================================================	
	//                                I N F O
	//=============================================================================	
	// Make a background box
	GUI.backgroundColor = new Color(1.0f, 1.0f, 1.0f, 0.5f);
	GUI.Box (new Rect (10, 825, 210, 100), "INFO:");
	GUI.backgroundColor = new Color(1.0f , 1.0f , 1.0f , 1.0f);
	GUI.Label (Rect (20, 850, 200, 20), "To start or stop for the animation ");
	GUI.Label (Rect (20, 870, 200, 20), "- click on the START / STOP.");
	GUI.Label (Rect (20, 890, 200, 20), "Select BRAKE for animation.");
	
	//=============================================================================	
	//                         N A V I G A T I O N
	//=============================================================================	
	// Make a background box
 	GUI.contentColor = Color.yellow;     
	GUI.backgroundColor = new Color(1.0f, 1.0f, 1.0f, 0.5f);
	GUI.Box (new Rect (Screen.width-450, 40, 410, 150), "NAVIGATION (MOUSE):");
	GUI.backgroundColor = new Color(1.0f , 1.0f , 1.0f , 1.0f);
	GUI.Label (Rect (Screen.width-450+10, 70, 400, 20), "Mouse Left Button: ");
	GUI.Label (Rect (Screen.width-450+10, 90, 400, 20), "Mouse Left Button + Left Shift: ");
	GUI.Label (Rect (Screen.width-450+10, 110, 400, 20), "Mouse Wheel: ");
	GUI.Label (Rect (Screen.width-450+10, 130, 400, 20), "Mouse Right Button: ");
	GUI.Label (Rect (Screen.width-450+10, 150, 400, 20), "Mouse Middle Button: ");
	GUI.contentColor = Color.white;     
	GUI.Label (Rect (Screen.width-450+230, 70, 400, 20), "Selelect Breaks (animation)");
	GUI.Label (Rect (Screen.width-450+230, 90, 400, 20), "Dragging to axis X and Z");
	GUI.Label (Rect (Screen.width-450+230, 110, 400, 20), "Zoom 1");
	GUI.Label (Rect (Screen.width-450+230, 130, 400, 20), "Zoom 2");
	GUI.Label (Rect (Screen.width-450+230, 150, 400, 20), "Camera Orbit");
	
	//==============================================================================
	//                              MENU AREA
	//============================================================================== 
	GUILayout.BeginArea(Rect(10, Screen.height-buttonHeight-10, (buttonWidth+2)*6, 100));
	GUILayout.BeginHorizontal();

	// (1) Button Ineractive 
	if(GUILayout.Button("Interactive", GUILayout.Height(buttonHeight)))
	{
		Application.LoadLevel("Main");
	}

	// (2) Button Simulation 
	if(GUILayout.Button("Lessons", GUILayout.Height(buttonHeight)))
	{
		Application.LoadLevel("Lessons");
	}

	// (3) Button Animation        
	if(GUILayout.Button("Animation", GUILayout.Height(buttonHeight)))
	{
		Application.LoadLevel("Anim1");
	}

	// (4) Slide-Show 
	if(GUILayout.Button("Sideshow", GUILayout.Height(buttonHeight)))
	{
		Application.LoadLevel("Slideshow");
	}

	// (5) HELP 
	if(GUILayout.Button("Help", GUILayout.Height(buttonHeight)))
	{
		Application.OpenURL ((Application.dataPath) + "./carm.rtf"); // Help File

	}

	// (6) Button FULLSCREEN        
	if(GUILayout.Button("FullScreen", GUILayout.Height(buttonHeight)))
	{
		Screen.fullScreen = !Screen.fullScreen; 
	}

	// (7) Button EXIT 
	if(GUILayout.Button("Exit", GUILayout.Height(buttonHeight)))
	{
		 Application.Quit(); 
	}

	GUILayout.EndHorizontal();
	GUILayout.EndArea();
	
	//======================================================================================
	//                               ANIMATION
 	//======================================================================================
 	GUI.contentColor = Color.yellow;     

	// START 
	if (GUI.Button (Rect (650, Screen.height-35, 100, 25), "START")) 
	{
		Application.LoadLevel("Anim2");
	}

	// STOP 
	if (GUI.Button (Rect (760, Screen.height-35, 100, 25), "STOP")) 
	{
		Application.LoadLevel("Anim1");
	}

}
