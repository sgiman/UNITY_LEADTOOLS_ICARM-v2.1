//------------------------------------------------------
// Menu GUI (MenuGUI.js)
//------------------------------------------------------
// Writing by Sergey Gasanov (sgiman.com) @ 2012-2013 
// Version: 3.1
//
// ICARM (Interactive presentation C-ARM)	
//------------------------------------------------------
var guiSkin: GUISkin;	

private var buttonWidth : int = 100; 
private var buttonHeight : int = 25;	
private var spacing:int = 2;


function OnGUI()
{   	 	 	    	
	GUI.skin = guiSkin;
  	
	//------------- HEADER ------------
	// 		Negative (MAXIMIZE) 
	//--------------------------------- 
	ObjVis = this.GetComponent("ObjVisual");	// Script ObjVisual.js ("Interactive")
	if (ObjVis.lat_ext2 && ObjVis.LatMaxIs)
	{	
		GUI.contentColor = Color.black;
  		GUI.Label (Rect (10, 10, 900, 20), this.GetComponent("Data").HeaderInt);
  		GUI.contentColor = Color.white;
	}
	else
	{
		GUI.contentColor = Color.white;
  		GUI.Label (Rect (10, 10, 900, 20), this.GetComponent("Data").HeaderInt);
	}
	
	// Menu Area
	GUILayout.BeginArea(Rect(10, Screen.height-buttonHeight-10, (buttonWidth+2)*6, 100));
	GUILayout.BeginHorizontal();

	// (1) Button Interactive 
	if(GUILayout.Button("Interactive", GUILayout.Height(buttonHeight)))
	{
		Application.LoadLevel("Main");
	}
	

	// (2) Button Simulation
	if(GUILayout.Button("Lessons", GUILayout.Height(buttonHeight)))
	{
		Application.LoadLevel("Lessons");
	}

	// (3) Button Animation        
	if(GUILayout.Button("Animation", GUILayout.Height(buttonHeight)))
	{
		Application.LoadLevel("Anim1");
	}

	// (4) Slide-Show 
	if(GUILayout.Button("Sideshow", GUILayout.Height(buttonHeight)))
	{
		Application.LoadLevel("Slideshow");
	}

	// (5) HELP 
	if(GUILayout.Button("Help", GUILayout.Height(buttonHeight)))
	{
		Application.OpenURL ((Application.dataPath) + "./carm.rtf"); // Help File
	}

	// (6) Button FULLSCREEN        
	if(GUILayout.Button("FullScreen", GUILayout.Height(buttonHeight)))
	{
		Screen.fullScreen = !Screen.fullScreen; 
	}

	// (7) Botton EXIT 
	if(GUILayout.Button("Exit", GUILayout.Height(buttonHeight)))
	{
		 Application.Quit(); 
	}

	GUILayout.EndHorizontal();
	GUILayout.EndArea();

}

