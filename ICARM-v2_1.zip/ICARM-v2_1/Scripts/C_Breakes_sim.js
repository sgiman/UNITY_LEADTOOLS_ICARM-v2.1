//==========================================
// C_Breakes_sim.js (Simulation)
//
// Writing Sergey Gasanov (sgiman.com) @ 2013
// version 2.7.3
//
// ICARM (Interactive presentation C-ARM)	
//-----------------------------------------
// Objects:
//-----------------------------------------
// C_FlipFlopMotion
// C_HorizontalExtension
// C_LArmRotation
// C_MotionOrbital
// C_VerticalLift
// C_WigWagMotion
//========================================= 
// Vector3.up,down,right,left,forward 
//-----------------------------------------
// up - rotate Y axis 
// down - rotate X axis
// right,left - rotate YZ axis (diagonal)
// vector3.forward - rotate Z axis  
//=========================================

var speedRot = 10.0;

// C-ARM MOVE
var speed = 1.0;
//var aLeft: Texture2D; 
//var aRight: Texture2D; 

// GuiSkin
var guiSkin: GUISkin;

// CENTERS
var CamCenter: GameObject;  // Center Cameras (AP/LAT)
var LineCenter: GameObject; // Centers Lines X-RAY

// C_FlipFlopMotion
var FlipFlop : GameObject;
private var FlipFlopAngX : float;

// C_HorizontalExtension
var HorExt : Transform;
private var HorExtVal : float;
private var v_hx : float;
private var t_hor : float;

// C_LArmRotation
var LArmRotation : GameObject;
private var LArmAngleX : float;

// C_MotionOrbital
var MotionOrbital : GameObject;
private var MotionOrbitalAngleZ : float;

// C_VerticalLift
var VerticalLift : Transform;
private var VerticalLiftVal : float;
private var v_hy : float;
private var t_vert : float;

// Table Controle
var TableBodyUp : GameObject;
private var TableY: float;

// C_WigWagMotion
var WigWag : GameObject;
var arrowLeft: Texture2D; 
var arrowRight: Texture2D; 
var rotateSpeed = 10;		
private var curAngle : float = 0;

// Sevices on-off
var carm : GameObject;  
var invert : boolean = false;	
var ww : boolean = false;			// ON-OFF option WigWag Motion

private var srv_ext1 : boolean = false;
private var srv_ext2 : boolean = false;

private var ang_c_arm : float = 0;  
private var first : boolean = false;
private var second : boolean = false;
private var neg : boolean = false; // Negative for MAXIMIZE AP-LAT	

// Windows
private var windowRect_carm_mov : Rect = Rect (5, 350, 210, 80);
private var windowRect_NavInfo : Rect = Rect (490, 750, 430, 150);

// Buttons GUIStyle's
public var ARROW_LEFT_BUTTON: GUIStyle;
public var ARROW_RIGHT_BUTTON: GUIStyle;


function Start () 
{
	FlipFlopAngX = 0;
	HorExtVal = -3.368088;
	LArmAngleX = 0;
	MotionOrbitalAngleZ = 61;
	VerticalLiftVal = 4.477582;
	TableY = 9.012033;
}	


function Update () 
{
	;
}


function OnGUI() {
	
	GUI.skin = guiSkin; // Current GUI Skin

	//--------------------------------- 
	// Negative (MAXIMIZE) 
	//--------------------------------- 
	ObjVisSim = this.GetComponent("ObjVisualSim"); // Script ObjVisual_sim.js ("simulation")
	if ((ObjVisSim.ap_ext2 && ObjVisSim.ApMaxIs) || (ObjVisSim.lat_ext2 && ObjVisSim.LatMaxIs))
	{
		GUI.contentColor = Color.black;
		neg = true;
	}	 
	else
	{
		GUI.contentColor = Color.white; 
		neg = false;
	}

	//===================================
	//  Make a background box "SERVCE"
	//===================================
	GUI.backgroundColor = new Color(1.0f, 1.0f, 1.0f, 0.5f);
	GUI.Box (new Rect (5, 790, 210, 110), "SERVICE:");
	GUI.backgroundColor = new Color(1.0f , 1.0f , 1.0f , 1.0f);

	// C-ARM MOVE
	if (neg)
	{
		GUI.contentColor = Color.white;
		windowRect_carm_mov = GUI.Window (1, windowRect_carm_mov, carm_move, "C-ARM MOVE:"); 
	}
	else
		windowRect_carm_mov = GUI.Window (1, windowRect_carm_mov, carm_move, "C-ARM MOVE:"); 

	//===========================================================================================
	//                                   INVERT C-ARM
	//===========================================================================================
	if (neg)
		GUI.contentColor = Color.black;
	else
		GUI.contentColor = Color.white;
		
	if ( invert )
	{	     
		srv_ext1 = GUI.Toggle (Rect (10, 815, 180, 20), srv_ext1, " Invert C-ARM");    
		GUI.enabled = true;        
	
		if (srv_ext1) 
		{
			ang_c_arm = 177;
			if (!first) {
				carm.transform.localPosition.z = -1; 
				first = true;
				second = false;
			}
		}
		else
		{
			ang_c_arm = 0;
			if (!second) {
				carm.transform.localPosition.z = 0;
				first = false;
				second = true;
			}
		}
					
		carm.transform.localEulerAngles = new Vector3( carm.transform.rotation.x, ang_c_arm, carm.transform.rotation.z );
	}
					
	GUI.enabled = true;        

	//============================ 
	//     NAVIGATION INFO
	//============================
	if (!neg)
	{
		GUI.contentColor = Color.yellow;       
		srv_ext2 = GUI.Toggle (Rect (10, 865, 180, 20), srv_ext2, " Navigation INFO");    
		GUI.contentColor = Color.white;	
	}
	else
	{
		GUI.contentColor = Color.black;       
		srv_ext2 = GUI.Toggle (Rect (10, 865, 180, 20), srv_ext2, " Navigation INFO");    
	}
	
	GUI.enabled = true;        
	if (srv_ext2) 
		windowRect_NavInfo = GUI.Window (123, windowRect_NavInfo, NavInfo, "NAVIGATION INFO:"); 


	//============================ 
	//      SLIDERS BREAKS
	//============================
	// Make a background box
	GUI.backgroundColor = Color(1.0f ,1.0f , 1.0f , 0.5f);
	GUI.Box (Rect (5,40,210,300), "C-ARM CONTROL:");
	GUI.backgroundColor = Color(1.0f , 1.0f , 1.0f , 1.0f);

	// (1) Orbital Motion (Angle Z) -- 
	GUI.Label(Rect(10, 60, 200, 30), "Orbital Motion: ");
	MotionOrbitalAngleZ = GUI.HorizontalSlider (Rect (10, 80, 200, 30), MotionOrbitalAngleZ, -61, 61);
	MotionOrbital.transform.localEulerAngles = new Vector3(transform.rotation.x, transform.rotation.y, MotionOrbitalAngleZ);
	CamCenter.transform.localEulerAngles = new Vector3(CamCenter.transform.rotation.x, CamCenter.transform.rotation.y, MotionOrbitalAngleZ-90);
	LineCenter.transform.localEulerAngles = new Vector3(LineCenter.transform.rotation.x, LineCenter.transform.rotation.y, MotionOrbitalAngleZ-90);
	
	// (2) Vertical Lift
	GUI.Label(Rect(10, 100, 200, 30), "Vertical Lift: ");
	VerticalLiftVal = GUI.HorizontalSlider (Rect (10, 120, 200, 30), VerticalLiftVal, 4.477582, 8.440429);
	v_hy = VerticalLiftVal;
	t_vert = Mathf.Round(v_hy * 100.0) / 100.0;
	VerticalLift.transform.localPosition.y = v_hy;

	// (3) Horizontal Extension (Y)
	GUI.Label(Rect(10, 140, 200, 30), "Horizontal Extension: ");
	HorExtVal = GUI.HorizontalSlider (Rect (10, 160, 200, 30), HorExtVal, -3.368088, -0.7925819);
	v_hx = HorExtVal;
	t_hor = Mathf.Round((v_hx+3.368088) * 100.0) / 100.0;
	HorExt.transform.localPosition.x = v_hx;

	// (4) Flip FlopMotion (Angle X)
	GUI.Label(Rect(10, 180, 200, 30), "Flip-Flop Motion: ");
	FlipFlopAngX = GUI.HorizontalSlider (Rect (10, 200, 200, 30), FlipFlopAngX, -45, 45);
	FlipFlop.transform.localEulerAngles = new Vector3(FlipFlopAngX, transform.rotation.y, transform.rotation.z);

	// (5) L-ARM Rotaton (Angle Z)
	GUI.Label(Rect(10, 220, 200, 30), "L-ARM Rotaton: ");
	LArmAngleX = GUI.HorizontalSlider (Rect (10, 240, 200, 30), LArmAngleX, -60, 60);
  	LArmRotation.transform.localEulerAngles = new Vector3(LArmAngleX, transform.rotation.y, transform.rotation.z);

    // (6) Table Controle
	GUI.Label(Rect(10, 260, 200, 30), "Table Height: ");
	TableY = GUI.HorizontalSlider (Rect (10, 280, 200, 30), TableY, 6, 9.012033);
	v_hy = TableY;
	t_vert = Mathf.Round(v_hy * 100.0) / 100.0;
	TableBodyUp.transform.localPosition.y = v_hy;

	// (7) Button RESET 
	GUI.contentColor = Color.white;
	if (GUI.Button (Rect (10, 310, 200, 25), "Reset")) 
	{
		FlipFlopAngX = 0;
		HorExtVal = -3.368088;
		LArmAngleX = 0;
		MotionOrbitalAngleZ = 61;
		VerticalLiftVal = 4.477582;
		TableY = 9.012033;
	}

 	//----------------------- 
 	//--- Wig-Wag Motion ---
	//----------------------
	if (ww) 
	{
		GUI.Label (Rect (60, 440, 200, 25), "Wig-Wag Motion"); 

		if(GUI.RepeatButton (Rect (60,460,35,35), "", ARROW_LEFT_BUTTON))
		{
    		curAngle = rotateSpeed * Time.deltaTime;
      		WigWag.transform.Rotate (Vector3.down, curAngle);
		}
		

		if(GUI.RepeatButton (Rect (120,460,35,35), "", ARROW_RIGHT_BUTTON))
		{
    		curAngle = rotateSpeed * Time.deltaTime;
      		WigWag.transform.Rotate (Vector3.up, curAngle);
		}
	}

}


//================================================
//                  Window C-ARM moving
//================================================  
function carm_move (windowID : int) {
    // Move C-ARM Forward/Back    
	GUI.Label (Rect (10, 20 ,200, 25), "Forward / Back"); 
	if(GUI.RepeatButton (Rect (10, 40, 35, 35), "", ARROW_LEFT_BUTTON))
	{
		carm.transform.Translate(Vector3.right * Time.deltaTime * speed);	
	}
	if(GUI.RepeatButton (Rect (50, 40, 35, 35), "", ARROW_RIGHT_BUTTON))
	{
		carm.transform.Translate(Vector3.left * Time.deltaTime * speed);
	}

    // Move C-ARM Right/Left    
	GUI.Label (Rect (120, 20 ,200, 25), "Left / Right"); 
	if(GUI.RepeatButton (Rect (120, 40, 35, 35), "", ARROW_LEFT_BUTTON))
	{
		carm.transform.Translate(Vector3.forward * Time.deltaTime * speed);	
	}
	if(GUI.RepeatButton (Rect (160, 40, 35, 35), "", ARROW_RIGHT_BUTTON))
	{
		carm.transform.Translate(Vector3.back * Time.deltaTime * speed);
	}
	
	GUI.DragWindow (Rect (0,0,10000,10000));
}


//================================================
//          Window "NAVIGATION INFO"
//================================================  
function NavInfo (windowID : int) 
{
	if (neg)
	{
		GUI.contentColor = Color.black; 
		GUI.Label(Rect(10, 30, 400, 25), "LEFT SHIFT + LEFT MOUSE BTN: "); 
		GUI.Label(Rect(10, 50, 400, 25), "WHEEL MOUSE : "); 
		GUI.Label(Rect(10, 70, 400, 30), "RIGHT MOUSE BTN : "); 
		GUI.Label(Rect(10, 90, 400, 30), "MIDDLE MOUSE BTN : "); 

		GUI.Label(Rect(230, 30, 400, 25), "Dragging Camera (Main View)"); 
		GUI.Label(Rect(230, 50, 400, 25), "Zoom 1 (Main View)"); 
		GUI.Label(Rect(230, 70, 400, 30), "Zoom 2 (Main View)"); 
		GUI.Label(Rect(230, 90, 400, 30), "Camera Orbit (Main View)"); 
	}
	else
	{
		GUI.contentColor = Color.yellow; 
		GUI.Label(Rect(10, 30, 400, 25), "LEFT SHIFT + LEFT MOUSE BTN: "); 
		GUI.Label(Rect(10, 50, 400, 25), "WHEEL MOUSE : "); 
		GUI.Label(Rect(10, 70, 400, 30), "RIGHT MOUSE BTN : "); 
		GUI.Label(Rect(10, 90, 400, 30), "MIDDLE MOUSE BTN : "); 

		GUI.contentColor = Color.white; 
		GUI.Label(Rect(230, 30, 400, 25), "Dragging Camera (Main View)"); 
		GUI.Label(Rect(230, 50, 400, 25), "Zoom 1 (Main View)"); 
		GUI.Label(Rect(230, 70, 400, 30), "Zoom 2 (Main View)"); 
		GUI.Label(Rect(230, 90, 400, 30), "Camera Orbit (Main View)"); 
	}
	
	GUI.DragWindow (Rect (0,0,10000,10000));

}

