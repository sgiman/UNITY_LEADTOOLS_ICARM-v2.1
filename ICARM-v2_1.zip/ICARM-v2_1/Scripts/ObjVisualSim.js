/**************************************************** 
  ObjVisual-sim.js 
  Objects Visual 
-----------------------------------------------------
  Writing by Sergey Gasanov (sgiman.com) @ 2012-2013
  Version: 1.1
  
  ICARM (Interactive presentation C-ARM)	
*****************************************************/
//GUI
var guiSkin: GUISkin;
var hSensitivity = 0.025;
var vSensitivity = 0.025;


//Spine X-RAY
var sacrum_1 : Renderer;
var sacrum_2 : Renderer;

var disk_C1_L : Renderer;
var disk_C1_R : Renderer;
var disk_C2 : Renderer;
var disk_C3 : Renderer;
var disk_C4 : Renderer;
var disk_C5 : Renderer;
var disk_C6 : Renderer;
var disk_C7 : Renderer;
var disk_L1 : Renderer;
var disk_L2 : Renderer;
var disk_L3 : Renderer;
var disk_L4 : Renderer;
var disk_L5 : Renderer;
var disk_T1 : Renderer;
var disk_T2 : Renderer;
var disk_T3 : Renderer;
var disk_T4 : Renderer;
var disk_T5 : Renderer;
var disk_T6 : Renderer;
var disk_T7 : Renderer;
var disk_T8 : Renderer;
var disk_T9 : Renderer;
var disk_T10 : Renderer;
var disk_T11 : Renderer;
var disk_T12 : Renderer;

var Vert_C1 : Renderer;
var Vert_C2 : Renderer;
var Vert_C3 : Renderer;
var Vert_C4 : Renderer;
var Vert_C5 : Renderer;
var Vert_C6 : Renderer;
var Vert_C7 : Renderer;
var Vert_L1 : Renderer;
var Vert_L2 : Renderer;
var Vert_L3 : Renderer;
var Vert_L4 : Renderer;
var Vert_L5 : Renderer;
var Vert_T1 : Renderer;
var Vert_T2 : Renderer;
var Vert_T3 : Renderer;
var Vert_T4 : Renderer;
var Vert_T5 : Renderer;
var Vert_T6 : Renderer;
var Vert_T7 : Renderer;
var Vert_T8 : Renderer;
var Vert_T9 : Renderer;
var Vert_T10 : Renderer;
var Vert_T11 : Renderer;
var Vert_T12 : Renderer;


//Spine REAL
var r_sacrum_1 : Renderer;
var r_sacrum_2 : Renderer;

var r_disk_C1_L : Renderer;
var r_disk_C1_R : Renderer;
var r_disk_C2 : Renderer;
var r_disk_C3 : Renderer;
var r_disk_C4 : Renderer;
var r_disk_C5 : Renderer;
var r_disk_C6 : Renderer;
var r_disk_C7 : Renderer;
var r_disk_L1 : Renderer;
var r_disk_L2 : Renderer;
var r_disk_L3 : Renderer;
var r_disk_L4 : Renderer;
var r_disk_L5 : Renderer;
var r_disk_T1 : Renderer;
var r_disk_T2 : Renderer;
var r_disk_T3 : Renderer;
var r_disk_T4 : Renderer;
var r_disk_T5 : Renderer;
var r_disk_T6 : Renderer;
var r_disk_T7 : Renderer;
var r_disk_T8 : Renderer;
var r_disk_T9 : Renderer;
var r_disk_T10 : Renderer;
var r_disk_T11 : Renderer;
var r_disk_T12 : Renderer;

var r_Vert_C1 : Renderer;
var r_Vert_C2 : Renderer;
var r_Vert_C3 : Renderer;
var r_Vert_C4 : Renderer;
var r_Vert_C5 : Renderer;
var r_Vert_C6 : Renderer;
var r_Vert_C7 : Renderer;
var r_Vert_L1 : Renderer;
var r_Vert_L2 : Renderer;
var r_Vert_L3 : Renderer;
var r_Vert_L4 : Renderer;
var r_Vert_L5 : Renderer;
var r_Vert_T1 : Renderer;
var r_Vert_T2 : Renderer;
var r_Vert_T3 : Renderer;
var r_Vert_T4 : Renderer;
var r_Vert_T5 : Renderer;
var r_Vert_T6 : Renderer;
var r_Vert_T7 : Renderer;
var r_Vert_T8 : Renderer;
var r_Vert_T9 : Renderer;
var r_Vert_T10 : Renderer;
var r_Vert_T11 : Renderer;
var r_Vert_T12 : Renderer;


var matDisk : Material;		// Opaque
var matVert : Material;		// Opaque

var matXray : Material; 	// XRAY MAIN
var matXray2 : Material; 	// X-RAY2

var matSelGreen : Material; 	// for select Vert
var matSelRose : Material; 		// for select Disk

//Cameras
var cam1 : Camera; // Camera MAIN 
var cam2 : Camera; // Camera AP 
var cam3 : Camera; // Camera LAT

private var hSliderZoom_lat : int;	// Zoom LAT
private var hSliderZoom_ap : int;	// Zoom AP

// HIDE OBJECTS (MAIN) 
private var ext1 : boolean = true;	// C-ARM
private var ext2 : boolean = false;	// TABLE
private var ext3 : boolean = true;	// BODY
private var ext4 : boolean = true;	// SPINE
private var ext5 : boolean = true;	// NERVES
private var ext6 : boolean = true;	// BONES

private var e1 : boolean = true;	// C-ARM
private var e2 : boolean = false;	// TABLE
private var e3 : boolean = true;	// BODY
private var e4 : boolean = true;	// SPINE
private var e5 : boolean = true;	// NERVES
private var e6 : boolean = true;	// BONES


// ON-OFF (LAT)
private var lat_ext1 : boolean = true;	// X-Ray
private var lat_ext2 : boolean = false;	// Negative
private var lat_ext3 : boolean = true;	// Bones
private var lat_ext4 : boolean = false;	// Nerves

// ON-OFF (AP)
private var ap_ext1 : boolean = true;	// X-Ray
private var ap_ext2 : boolean = false;	// Negative
private var ap_ext3 : boolean = true;	// Bones
private var ap_ext4 : boolean = false;	// Nerves

// CORRECT (Xray material)
private var hSliderRim : float; 		// Bright (Rim 1-2) 
private var hSliderInside : float;		// Bright (Inside 0-1)
private var cor_ext : boolean = false;	// Correct Options

// Make the contents of the window (Patient)
private var BodyXray : int = 1; 				// BODY-XRAY
private var BodyTransIs : boolean = false;		// Flag Body Transparent
private var str : String[] = ["Real", "X-Ray"]; // PATIENT 

private var PosApCam : Vector3;
private var PosLatCam : Vector3;

// Boolean's
private var ThreeScreenIs : boolean = true;
private var ApMaxIs : boolean = false;
private var LatMaxIs : boolean = false;
private var MainMaxIs : boolean = false;
private var SpineDiskIs : boolean = false;
private var SpineVertIs : boolean = false;

// Contrast
private var hSliderContrast_ap : float = 0.0; 
private var hSliderContrast_lat : float = 0.0;

// Windows
private var windowRectPatinet : Rect = Rect (5, 500, 210, 60); 			// Window "PATIENT" 
private var windowRectBrightness : Rect = Rect (700, 580, 220, 150);	// Window "BRIGHNTESS"
private var windowRectSpineDisk : Rect = Rect (290, 40, 150, 550);		// Window "SPINE PARTS"
private var windowRectSpineVert : Rect = Rect (460, 40, 150, 550);		// Window "SPINE PARTS"

// Rects Bottons AP/LAT views
private var Rect_AP_Max_Min : Rect = Rect (Screen.width-80, 10, 36, 36);					// Max-Min AP
private var Rect_AP_Reset : Rect = Rect (Screen.width-125, 10, 36, 36);						// Reset AP

private var Rect_LAT_Max_Min : Rect = Rect (Screen.width-80, Screen.height/2+15, 36, 36);	// Max-Min AP
private var Rect_LAT_Reset : Rect = Rect (Screen.width-125, Screen.height/2+15, 36, 36);	// Reset LAT

private var Rect_MainMin : Rect = Rect (Screen.width/2-100, 10, 36, 36);					// Max-Min MAIN
private var Rect_MainMax : Rect = Rect (Screen.width-100, 10, 36, 36);						// Max-Min MAIN
private var Rect_Main : Rect;

private var MinView : String = "MIN";
private var MaxView : String = "MAX";
private var View : String = "MAX";
private var ResetView : String = "RESET";

// Buttons GUIStyle's
public var NAV_WIN_RESET_BUTTON: GUIStyle;
public var NAV_WIN_MAX_MIN: GUIStyle;

// Brithess X-Ray
private var xRim : float = 0.35;
private var xInside : float = 0.15 ;

// Spine Parts
private var ext_disk_C1_L : boolean = false; 
private var ext_disk_C1_R : boolean = false;
private var ext_disk_C2 : boolean = false;
private var ext_disk_C3 : boolean = false;
private var ext_disk_C4 : boolean = false;
private var ext_disk_C5 : boolean = false;
private var ext_disk_C6 : boolean = false;
private var ext_disk_C7 : boolean = false;

private var ext_disk_L1 : boolean = false;
private var ext_disk_L2 : boolean = false;
private var ext_disk_L3 : boolean = false;
private var ext_disk_L4 : boolean = false;
private var ext_disk_L5 : boolean = false;

private var ext_disk_T1 : boolean = false;
private var ext_disk_T2 : boolean = false;
private var ext_disk_T3 : boolean = false;
private var ext_disk_T4 : boolean = false;
private var ext_disk_T5 : boolean = false;
private var ext_disk_T6 : boolean = false;
private var ext_disk_T7 : boolean = false;
private var ext_disk_T8 : boolean = false;
private var ext_disk_T9 : boolean = false;
private var ext_disk_T10 : boolean = false;
private var ext_disk_T11 : boolean = false;
private var ext_disk_T12 : boolean = false;

private var ext_Vert_C1 : boolean = false;
private var ext_Vert_C2 : boolean = false;
private var ext_Vert_C3 : boolean = false;
private var ext_Vert_C4 : boolean = false;
private var ext_Vert_C5 : boolean = false;
private var ext_Vert_C6 : boolean = false;
private var ext_Vert_C7 : boolean = false;

private var ext_Vert_L1 : boolean = false;
private var ext_Vert_L2 : boolean = false;
private var ext_Vert_L3 : boolean = false;
private var ext_Vert_L4 : boolean = false;
private var ext_Vert_L5 : boolean = false;
	
private var ext_Vert_T1 : boolean = false;
private var ext_Vert_T2 : boolean = false;
private var ext_Vert_T3 : boolean = false;
private var ext_Vert_T4 : boolean = false;
private var ext_Vert_T5 : boolean = false;
private var ext_Vert_T6 : boolean = false;
private var ext_Vert_T7 : boolean = false;
private var ext_Vert_T8 : boolean = false;
private var ext_Vert_T9 : boolean = false;
private var ext_Vert_T10 : boolean = false;
private var ext_Vert_T11 : boolean = false;
private var ext_Vert_T12 : boolean = false;

private var ext_sacrum : boolean = false;



//************************* 
//         START 
//*************************
function Start ()  
{
	// Brightness X-Ray Spine
	SpineXraySet (xRim, xInside);	// Sart Set X-Ray for Spine  - SpineXraySet(Rim, Inside)    
	hSliderRim = xRim; 				// Bright (Rim 1-2) 
	hSliderInside = xInside;		// Bright (Inside 0-1)
	
	// Defalult camera parameters
	hSliderZoom_ap = 15;		// FOV AP
	hSliderZoom_lat = 15;		// FOV LAT
  
	// Enable Cameras
	cam1.GetComponent.<Camera>().active = true;	// MAIN VIEW
   	cam2.enabled = true;		// AP VIEW
   	cam3.enabled = true;		// LAT VIEW
	
	// Size cameras windows (X,Y,W,H) 
	cam1.rect = new Rect(0, 0, 0.5, 1);			// MAIN RECT
	cam2.rect = new Rect(0.5, 0.5, 1, 0.5);		// AP RECT
	cam3.rect = new Rect(0.5, 0, 0.5, 0.499);	// LAT RECT
   	
   	// Option "Negative" for AP & LAT
   	cam2.GetComponent("GrayscaleEffect").enabled = false;	// AP Nagative = OFF
   	cam3.GetComponent("GrayscaleEffect").enabled = false;	// LAT Nagative = OFF  
   	
	// Set layers
	cam2.cullingMask &= ~(1 << 16);	// OFF Layer "Bones"
	cam2.cullingMask &= ~(1 << 20);	// OFF Layer "BonesX"
	cam2.cullingMask &= ~(1 << 17);	// OFF Layer "Nerves"
	cam2.cullingMask &= ~(1 << 19);	// OFF Layer "NervesX"

	cam3.cullingMask &= ~(1 << 16);	// OFF Layer "Bones"
	cam3.cullingMask &= ~(1 << 20);	// OFF Layer "BonesX"
	cam3.cullingMask &= ~(1 << 17);	// OFF Layer "Nerves"
	cam3.cullingMask &= ~(1 << 19);	// OFF Layer "NervesX"
	   	
  	PosApCam = cam2.transform.localPosition;	// Save Camera AP position
	PosLatCam = cam3.transform.localPosition;	// Save Camera LAT position
	
}
//**************************** END Start() ********************************


//************************* 
//	        OnGUI 
//*************************
function OnGUI()
{   	 	 	    	
	GUI.skin = guiSkin;
	
	// SPINE PARTS
	//===================================
	//  Make a background box 1
	//===================================
	GUI.backgroundColor = new Color(1.0f, 1.0f, 1.0f, 0.5f);
	GUI.Box (new Rect (290, 5, 150, 30), "");
	GUI.backgroundColor = new Color(1.0f , 1.0f , 1.0f , 1.0f);

	//===================================
	//  Make a background box 2
	//===================================
	GUI.backgroundColor = new Color(1.0f, 1.0f, 1.0f, 0.5f);
	GUI.Box (new Rect (460, 5, 150, 30), "");
	GUI.backgroundColor = new Color(1.0f , 1.0f , 1.0f , 1.0f);

	SpineDiskIs = GUI.Toggle (Rect (300, 10, 150, 20), SpineDiskIs, " SPINE DISK:"); 
	SpineVertIs = GUI.Toggle (Rect (470, 10, 150, 20), SpineVertIs, " SPINE VERT:"); 
	GUI.enabled = true; 
	
	if (SpineDiskIs) 
		windowRectSpineDisk = GUI.Window (44, windowRectSpineDisk, WinSpineDisk, "SPINE DISK:"); 		   
	
	if (SpineVertIs)
		windowRectSpineVert = GUI.Window (55, windowRectSpineVert, WinSpineVert, "SPINE VERT:"); 		   

	e1 = ext1;	// C-ARM
	e2 = ext2;	// TABLE
	e3 = ext3;	// BODY
	e4 = ext4;	// SPINE
	e5 = ext5;	// NERVES
	e5 = ext6;	// BONES

	if (SpineDiskIs || SpineVertIs)
	{
		ext1 = false;	// C-ARM
		ext2 = false;	// TABLE
		ext3 = false;	// BODY
		ext4 = true;	// SPINE
		ext5 = false;	// NERVES
		ext6 = false;	// BONES
	}
	
	HideObjectsMainView (); // On-Off Objects for MAIN view
	
	ApInit ();				// Initialize AP View
	
	LatInit ();				// Initialize Lat View
				
	//-------------------
	//  C O N T R O L
	//-------------------
	// Window PATIENT (Body/X-Ray)
	if (!ApMaxIs && !LatMaxIs)
	windowRectPatinet = GUI.Window (77, windowRectPatinet, WinPatient, "BODY PATIENT:");    

	CamPan (); // Camera Dragging (PAN)

	//-------------------
	//   ADD BUTTONS 
	//-------------------
	// RESET ALL
	if (GUI.Button (Rect (650, Screen.height-35, 100, 25), "Reset All")) 
	{
		Application.LoadLevel("Lessons");
	}

	MaxMinViews(); // Maximize-Minimize Views MAIN, AP, LAT

}
//**************************** END OnGUI() ************************************


//================================== 
//      Window Spine Disks 
//================================== 
function WinSpineDisk (windowID : int) 
{    
	ext_disk_C1_L = GUI.Toggle (Rect (10, 20, 150, 20), ext_disk_C1_L, " disk_C1_L"); 
	ext_disk_C1_R = GUI.Toggle (Rect (10, 40, 150, 20), ext_disk_C1_R, " disk_C1_R");
	ext_disk_C2 = GUI.Toggle (Rect (10, 60, 150, 20), ext_disk_C2, " disk_C2");
	ext_disk_C3 = GUI.Toggle (Rect (10, 80, 150, 20), ext_disk_C3, " disk_C3");
	ext_disk_C4 = GUI.Toggle (Rect (10, 100, 150, 20), ext_disk_C4, " disk_C4");
	ext_disk_C5 = GUI.Toggle (Rect (10, 120, 150, 20), ext_disk_C5, " disk_C5");
	ext_disk_C6 = GUI.Toggle (Rect (10, 140, 150, 20), ext_disk_C6, " disk_C6");
	ext_disk_C7 = GUI.Toggle (Rect (10, 160, 150, 20), ext_disk_C7, " disk_C7");
	ext_disk_T1 = GUI.Toggle (Rect (10, 180, 150, 20), ext_disk_T1, " disk_T1");
	ext_disk_T2 = GUI.Toggle (Rect (10, 200, 150, 20), ext_disk_T2, " disk_T2");
	ext_disk_T3 = GUI.Toggle (Rect (10, 220, 150, 20), ext_disk_T3, " disk_T3");
	ext_disk_T4 = GUI.Toggle (Rect (10, 240, 150, 20), ext_disk_T4, " disk_T4");
	ext_disk_T5 = GUI.Toggle (Rect (10, 260, 150, 20), ext_disk_T5, " disk_T5");
	ext_disk_T6 = GUI.Toggle (Rect (10, 280, 150, 20), ext_disk_T6, " disk_T6");
	ext_disk_T7 = GUI.Toggle (Rect (10, 300, 150, 20), ext_disk_T7, " disk_T7");
	ext_disk_T8 = GUI.Toggle (Rect (10, 320, 150, 20), ext_disk_T8, " disk_T8");
	ext_disk_T9 = GUI.Toggle (Rect (10, 340, 150, 20), ext_disk_T9, " disk_T9");
	ext_disk_T10 = GUI.Toggle (Rect (10, 360, 150, 20), ext_disk_T10, " disk_T10");
	ext_disk_T11 = GUI.Toggle (Rect (10, 380, 150, 20), ext_disk_T11, " disk_T11");
	ext_disk_T12 = GUI.Toggle (Rect (10, 400, 150, 20), ext_disk_T12, " disk_T12");
	ext_disk_L1 = GUI.Toggle (Rect (10, 420, 150, 20), ext_disk_L1, " disk_L1");
	ext_disk_L2 = GUI.Toggle (Rect (10, 440, 150, 20), ext_disk_L2, " disk_L2");
	ext_disk_L3 = GUI.Toggle (Rect (10, 460, 150, 20), ext_disk_L3, " disk_L3");
	ext_disk_L4 = GUI.Toggle (Rect (10, 480, 150, 20), ext_disk_L4, " disk_L4");
	ext_disk_L5 = GUI.Toggle (Rect (10, 500, 150, 20), ext_disk_L5, " disk_L5");

	GUI.enabled = true;        

	//disk_C1_L
	if (ext_disk_C1_L)
		r_disk_C1_L.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_C1_L.GetComponent.<Renderer>().material = matDisk;
	//disk_C1_R
	if (ext_disk_C1_R)
		r_disk_C1_R.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_C1_R.GetComponent.<Renderer>().material = matDisk;


	//disk_C2
	if (ext_disk_C2)
		r_disk_C2.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_C2.GetComponent.<Renderer>().material = matDisk;
	//disk_C3
	if (ext_disk_C3)
		r_disk_C3.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_C3.GetComponent.<Renderer>().material = matDisk;
	//disk_C4
	if (ext_disk_C4)
		r_disk_C4.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_C4.GetComponent.<Renderer>().material = matDisk;
	//disk_C5
	if (ext_disk_C5)
		r_disk_C5.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_C5.GetComponent.<Renderer>().material = matDisk;
	//disk_C6
	if (ext_disk_C6)
		r_disk_C6.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_C6.GetComponent.<Renderer>().material = matDisk;
	//disk_C7
	if (ext_disk_C7)
		r_disk_C7.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_C7.GetComponent.<Renderer>().material = matDisk;


	//disk_T1
	if (ext_disk_T1)
		r_disk_T1.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_T1.GetComponent.<Renderer>().material = matDisk;
	//disk_T2
	if (ext_disk_T2)
		r_disk_T2.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_T2.GetComponent.<Renderer>().material = matDisk;
	//disk_T3
	if (ext_disk_T3)
		r_disk_T3.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_T3.GetComponent.<Renderer>().material = matDisk;
	//disk_T4
	if (ext_disk_T4)
		r_disk_T4.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_T4.GetComponent.<Renderer>().material = matDisk;
	//disk_T5
	if (ext_disk_T5)
		r_disk_T5.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_T5.GetComponent.<Renderer>().material = matDisk;
	//disk_T6
	if (ext_disk_T6)
		r_disk_T6.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_T6.GetComponent.<Renderer>().material = matDisk;
	//disk_T7
	if (ext_disk_T7)
		r_disk_T7.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_T7.GetComponent.<Renderer>().material = matDisk;
	//disk_T8
	if (ext_disk_T8)
		r_disk_T8.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_T8.GetComponent.<Renderer>().material = matDisk;
	//disk_T9
	if (ext_disk_T9)
		r_disk_T9.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_T9.GetComponent.<Renderer>().material = matDisk;
	//disk_T10
	if (ext_disk_T10)
		r_disk_T10.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_T10.GetComponent.<Renderer>().material = matDisk;
	//disk_T11
	if (ext_disk_T11)
		r_disk_T11.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_T11.GetComponent.<Renderer>().material = matDisk;
	//disk_T12
	if (ext_disk_T12)
		r_disk_T12.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_T12.GetComponent.<Renderer>().material = matDisk;


	//disk_L1
	if (ext_disk_L1)
		r_disk_L1.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_L1.GetComponent.<Renderer>().material = matDisk;
	//disk_L2
	if (ext_disk_L2)
		r_disk_L2.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_L2.GetComponent.<Renderer>().material = matDisk;
	//disk_L3
	if (ext_disk_L3)
		r_disk_L3.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_L3.GetComponent.<Renderer>().material = matDisk;
	//disk_L4
	if (ext_disk_L4)
		r_disk_L4.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_L4.GetComponent.<Renderer>().material = matDisk;
	//disk_L5
	if (ext_disk_L5)
		r_disk_L5.GetComponent.<Renderer>().material = matSelRose;
	else
		r_disk_L5.GetComponent.<Renderer>().material = matDisk;

	GUI.DragWindow (Rect (0,0,10000,10000));	

}


//================================== 
//      Window Spine Vert's 
//================================== 
function WinSpineVert (windowID : int) 
{    

	ext_Vert_C1 = GUI.Toggle (Rect (10, 20, 150, 20), ext_Vert_C1, " vert_C1");
	ext_Vert_C2 = GUI.Toggle (Rect (10, 40, 150, 20), ext_Vert_C2, " vert_C2");
	ext_Vert_C3 = GUI.Toggle (Rect (10, 60, 150, 20), ext_Vert_C3, " vert_C3");
	ext_Vert_C4 = GUI.Toggle (Rect (10, 80, 150, 20), ext_Vert_C4, " vert_C4");
	ext_Vert_C5 = GUI.Toggle (Rect (10, 100, 150, 20), ext_Vert_C5, " vert_C5");
	ext_Vert_C6 = GUI.Toggle (Rect (10, 120, 150, 20), ext_Vert_C6, " vert_C6");
	ext_Vert_C7 = GUI.Toggle (Rect (10, 140, 150, 20), ext_Vert_C7, " vert_C7");
	ext_Vert_T1 = GUI.Toggle (Rect (10, 160, 150, 20), ext_Vert_T1, " vert_T1");
	ext_Vert_T2 = GUI.Toggle (Rect (10, 180, 150, 20), ext_Vert_T2, " vert_T2");
	ext_Vert_T3 = GUI.Toggle (Rect (10, 200, 150, 20), ext_Vert_T3, " vert_T3");
	ext_Vert_T4 = GUI.Toggle (Rect (10, 220, 150, 20), ext_Vert_T4, " vert_T4");
	ext_Vert_T5 = GUI.Toggle (Rect (10, 240, 150, 20), ext_Vert_T5, " vert_T5");
	ext_Vert_T6 = GUI.Toggle (Rect (10, 260, 150, 20), ext_Vert_T6, " vert_T6");
	ext_Vert_T7 = GUI.Toggle (Rect (10, 280, 150, 20), ext_Vert_T7, " vert_T7");
	ext_Vert_T8 = GUI.Toggle (Rect (10, 300, 150, 20), ext_Vert_T8, " vert_T8");
	ext_Vert_T9 = GUI.Toggle (Rect (10, 320, 150, 20), ext_Vert_T9, " vert_T9");
	ext_Vert_T10 = GUI.Toggle (Rect (10, 340, 150, 20), ext_Vert_T10, " vert_T10");
	ext_Vert_T11 = GUI.Toggle (Rect (10, 360, 150, 20), ext_Vert_T11, " vert_T11");
	ext_Vert_T12 = GUI.Toggle (Rect (10, 380, 150, 20), ext_Vert_T12, " vert_T12");
	ext_Vert_L1 = GUI.Toggle (Rect (10, 400, 150, 20), ext_Vert_L1, " vert_L1");
	ext_Vert_L2 = GUI.Toggle (Rect (10, 420, 150, 20), ext_Vert_L2, " vert_L2");
	ext_Vert_L3 = GUI.Toggle (Rect (10, 440, 150, 20), ext_Vert_L3, " vert_L3");
	ext_Vert_L4 = GUI.Toggle (Rect (10, 460, 150, 20), ext_Vert_L4, " vert_L4");
	ext_Vert_L5 = GUI.Toggle (Rect (10, 480, 150, 20), ext_Vert_L5, " vert_L5");

	ext_sacrum = GUI.Toggle (Rect (10, 500, 150, 20), ext_sacrum, " Sacrum");

	GUI.enabled = true;        

	//Vert_C1
	if (ext_Vert_C1)
		r_Vert_C1.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_C1.GetComponent.<Renderer>().material = matVert;
	//Vert_C2
	if (ext_Vert_C2)
		r_Vert_C2.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_C2.GetComponent.<Renderer>().material = matVert;
	//Vert_C3
	if (ext_Vert_C3)
		r_Vert_C3.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_C3.GetComponent.<Renderer>().material = matVert;
	//Vert_C4
	if (ext_Vert_C4)
		r_Vert_C4.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_C4.GetComponent.<Renderer>().material = matVert;
	//Vert_C5
	if (ext_Vert_C5)
		r_Vert_C5.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_C5.GetComponent.<Renderer>().material = matVert;
	//Vert_C6
	if (ext_Vert_C6)
		r_Vert_C6.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_C6.GetComponent.<Renderer>().material = matVert;
	//Vert_C7
	if (ext_Vert_C7)
		r_Vert_C7.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_C7.GetComponent.<Renderer>().material = matVert;


	//Vert_T1
	if (ext_Vert_T1)
		r_Vert_T1.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_T1.GetComponent.<Renderer>().material = matVert;
	//Vert_T2
	if (ext_Vert_T2)
		r_Vert_T2.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_T2.GetComponent.<Renderer>().material = matVert;
	//Vert_T3
	if (ext_Vert_T3)
		r_Vert_T3.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_T3.GetComponent.<Renderer>().material = matVert;
	//Vert_T4
	if (ext_Vert_T4)
		r_Vert_T4.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_T4.GetComponent.<Renderer>().material = matVert;
	//Vert_T5
	if (ext_Vert_T5)
		r_Vert_T5.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_T5.GetComponent.<Renderer>().material = matVert;
	//Vert_T6
	if (ext_Vert_T6)
		r_Vert_T6.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_T6.GetComponent.<Renderer>().material = matVert;
	//Vert_T7
	if (ext_Vert_T7)
		r_Vert_T7.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_T7.GetComponent.<Renderer>().material = matVert;
	//Vert_T8
	if (ext_Vert_T8)
		r_Vert_T8.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_T8.GetComponent.<Renderer>().material = matVert;
	//Vert_T9
	if (ext_Vert_T9)
		r_Vert_T9.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_T9.GetComponent.<Renderer>().material = matVert;
	//Vert_T10
	if (ext_Vert_T10)
		r_Vert_T10.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_T10.GetComponent.<Renderer>().material = matVert;
	//Vert_T11
	if (ext_Vert_T11)
		r_Vert_T11.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_T11.GetComponent.<Renderer>().material = matVert;
	//Vert_T12
	if (ext_Vert_T12)
		r_Vert_T12.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_T12.GetComponent.<Renderer>().material = matVert;


	//Vert_L1
	if (ext_Vert_L1)
		r_Vert_L1.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_L1.GetComponent.<Renderer>().material = matVert;
	//Vert_L2
	if (ext_Vert_L2)
		r_Vert_L2.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_L2.GetComponent.<Renderer>().material = matVert;
	//Vert_L3
	if (ext_Vert_L3)
		r_Vert_L3.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_L3.GetComponent.<Renderer>().material = matVert;
	//Vert_L4
	if (ext_Vert_L4)
		r_Vert_L4.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_L4.GetComponent.<Renderer>().material = matVert;
	//Vert_L5
	if (ext_Vert_L5)
		r_Vert_L5.GetComponent.<Renderer>().material = matSelGreen;
	else
		r_Vert_L5.GetComponent.<Renderer>().material = matVert;


	//sacrum
	if (ext_sacrum)
	{
		r_sacrum_1.GetComponent.<Renderer>().material = matSelGreen;
		r_sacrum_2.GetComponent.<Renderer>().material = matSelGreen;
	}
	else
	{
		r_sacrum_1.GetComponent.<Renderer>().material = matVert;
		r_sacrum_2.GetComponent.<Renderer>().material = matVert;
	}

	GUI.DragWindow (Rect (0,0,10000,10000));	

}


//================================== 
//         Window Patients 
//================================== 
function WinPatient (windowID : int) 
{    
	BodyXray = GUI.SelectionGrid (Rect (10, 20, 180, 30), BodyXray, str, 2);
	if(BodyXray == 0) BodyTransIs = false;	// Patient Real	
	if(BodyXray == 1) BodyTransIs = true;	// Transparent Patient
}



//================================== 
//       HIDE OBJECTS (MAIN) 
//================================== 
function HideObjectsMainView () 
{    
	// Options Main for three Screens
	if (ThreeScreenIs || MainMaxIs)
	{
		if (!ApMaxIs && !LatMaxIs)
		{
			// Make a background box
			GUI.backgroundColor = Color(1.0f ,1.0f , 1.0f , 0.5f);
			GUI.Box (Rect (5, 575, 210, 200), "ON / OFF:");
			GUI.backgroundColor = Color(1.0f , 1.0f , 1.0f , 1.0f);
			OptMain ();
		}	
	}
	
	// LABEL WINDOWS LAT/AP
	if (ThreeScreenIs && !ApMaxIs && !LatMaxIs && !MainMaxIs)
	{
		GUI.contentColor = Color.red;  
		GUI.Label (Rect (Screen.width-30, 10, 200, 20), "AP");
		GUI.contentColor = Color.green;  
		GUI.Label (Rect (Screen.width-30, Screen.height/2+15, 200, 20), "LAT");
		if (ap_ext2 || lat_ext2)	// Color for Negaive 
		{	
			GUI.contentColor = Color.black;
	  		GUI.Label (Rect (Screen.width-200, Screen.height/2-25, 200, 20), "Right Mouse Button: Dragging");
	  		GUI.contentColor = Color.white;
		}
		else
		{
			GUI.contentColor = Color.white;
	  		GUI.Label (Rect (Screen.width-200, Screen.height/2-25, 200, 20), "Right Mouse Button: Dragging");
		}
	}
	
	if (!ThreeScreenIs)
	{
		if (ApMaxIs)
		{
			GUI.contentColor = Color.red;  
			GUI.Label (Rect (Screen.width-30, 10, 200, 20), "AP");
		}
		
		if (LatMaxIs)
		{
			GUI.contentColor = Color.green;  
			GUI.Label (Rect (Screen.width-30, 10, 200, 20), "LAT");
		}
	}
	
	if (!MainMaxIs)
	{
		if (ap_ext2 || lat_ext2)	// Color for Negaive 
		{	
			GUI.contentColor = Color.black;
			GUI.Label (Rect (Screen.width-200, Screen.height-25, 200, 20), "Right Mouse Button: Dragging");
			GUI.contentColor = Color.white;
		}
		else
		{
			GUI.contentColor = Color.white;
			GUI.Label (Rect (Screen.width-200, Screen.height-25, 200, 20), "Right Mouse Button: Dragging");
			GUI.contentColor = Color.white;
		}

		if (lat_ext2)
		{
			GUI.contentColor = Color.black;
			GUI.Label (Rect (Screen.width/2+20, Screen.height-25, 200, 20), "C-ARM VIEW");
		}
		else
		{
			GUI.contentColor = Color.yellow;
			GUI.Label (Rect (Screen.width/2+20, Screen.height-25, 200, 20), "C-ARM VIEW");
			GUI.contentColor = Color.white;
		}
	}

}


//==================================== 
//  Options Main (for three sreens) 
//====================================
function OptMain ()
{
	ext1 = GUI.Toggle (Rect (10, 600, 180, 20), ext1, " C-ARM");    
	ext2 = GUI.Toggle (Rect (10, 620, 180, 20), ext2, " TABLE");    
	ext3 = GUI.Toggle (Rect (10, 660, 180, 20), ext3, " BODY");    
	ext4 = GUI.Toggle (Rect (10, 680, 180, 20), ext4, " SPINE");    
	ext5 = GUI.Toggle (Rect (10, 700, 180, 20), ext5, " NERVES");    
	ext6 = GUI.Toggle (Rect (10, 720, 180, 20), ext6, " BONES");    
	GUI.enabled = true;        

	// C-ARM (10)
	if(ext1) 
		cam1.cullingMask |= (1 << 10); // On 
	else
		cam1.cullingMask &= ~(1 << 10); // Off 

	// TABLE (14)
	if(ext2) 
		cam1.cullingMask |= (1 << 14); // On  
	else
		cam1.cullingMask &= ~(1 << 14); // Off 

	//--------------------- Body ----------------------------
	// BODY REAL (9,18)
	if(ext3 && !BodyTransIs) 
	{ 
		cam1.cullingMask |= (1 << 9); 	// ON 
		cam1.cullingMask &= ~(1 << 18);	// Off 
	}
	
	// BODY X-RAY (9,18)
	if(ext3 && BodyTransIs) 
	{ 
		cam1.cullingMask |= (1 << 18); 	// ON 
		cam1.cullingMask &= ~(1 << 9);	// Off 
	}
	
	// BODY REAL OFF (9,18)
	if(!ext3 && !BodyTransIs) 
	{ 
		cam1.cullingMask &= ~(1 << 9);	// Off 
		cam1.cullingMask &= ~(1 << 18);	// Off 
	}
	
	// BODY X-RAY & REAL OFF (9,18)
	if(!ext3 && BodyTransIs) 
	{ 
		cam1.cullingMask &= ~(1 << 9);	// Off 
		cam1.cullingMask &= ~(1 << 18);	// Off 
	}
	//-------------------------------------------------------

	// SPINE REAL (8,13)
	if(ext4)
	{ 
		cam1.cullingMask |= (1 << 8); 	// ON REAL
		cam1.cullingMask &= ~(1 << 13); // OFF XRAY
	}
	else
	{
		cam1.cullingMask &= ~(1 << 8);	// OFF REAL
		cam1.cullingMask &= ~(1 << 13); // OFF XRAY
	}
	
	// NERVES REAL (17,19)
	if(ext5) 
	{
		cam1.cullingMask |= (1 << 17);	// ON REAL
		cam1.cullingMask &= ~(1 << 19); // OFF XRAY
	}
	else
	{
		cam1.cullingMask &= ~(1 << 17); // OFF REAL
		cam1.cullingMask &= ~(1 << 19); // OFF XRAY
	}
	
	// BONES (16)
	if(ext6) 
		cam1.cullingMask |= (1 << 16); // On 
	else
		cam1.cullingMask &= ~(1 << 16); // Off 


}


//==================================== 
//          Options2 for AP MAX 
//====================================
function OptApMax ()
{
	//-------------------------------------------------------------------------- 
	//                      AP OPTIONS FOR AP MAX
	//--------------------------------------------------------------------------
	ap_ext1 = GUI.Toggle (Rect (10, 560, 180, 20), ap_ext1, " X-Ray Spine");    
	ap_ext2 = GUI.Toggle (Rect (10, 580, 180, 20), ap_ext2, " Negative");    
	ap_ext3 = GUI.Toggle (Rect (10, 620, 180, 20), ap_ext3, " Bones");    
	ap_ext4 = GUI.Toggle (Rect (10, 640, 180, 20), ap_ext4, " Nerves");    
	GUI.enabled = true;        
}


//==================================== 
//       Options2 for AP MAX 
//====================================
function OptLatMax ()
{
	//-------------------------------------------------------------------------- 
	//                      LAT OPTIONS FOR AP MAX
	//--------------------------------------------------------------------------
	lat_ext1 = GUI.Toggle (Rect (10, 560, 180, 20), lat_ext1, " X-Ray Spine");    
	lat_ext2 = GUI.Toggle (Rect (10, 580, 180, 20), lat_ext2, " Negative");    
	lat_ext3 = GUI.Toggle (Rect (10, 620, 180, 20), lat_ext3, " Bones");    
	lat_ext4 = GUI.Toggle (Rect (10, 640, 180, 20), lat_ext4, " Nerves");    
	GUI.enabled = true;        
}


//==================================== 
//   Options1 for AP three screens 
//====================================
function OptApThreeScreens ()
{
	if (!LatMaxIs)
	{
		//-------------------------------------------------------------------------- 
		//                AP OPTIONS FOR THREE SCREENS
		//--------------------------------------------------------------------------
		ap_ext1 = GUI.Toggle (Rect (Screen.width/2+20, 20, 180, 20), ap_ext1, " X-Ray Spine");    
		ap_ext2 = GUI.Toggle (Rect (Screen.width/2+20, 40, 180, 20), ap_ext2, " Negative");    
		ap_ext3 = GUI.Toggle (Rect (Screen.width/2+20, 80, 180, 20), ap_ext3, " Bones");    
		ap_ext4 = GUI.Toggle (Rect (Screen.width/2+20, 100, 180, 20), ap_ext4, " Nerves");    
		GUI.enabled = true;        
	}
}


//==================================== 
//  Options1 for LAT three screens 
//====================================
function OptLatThreeScreens ()
{
	if (!ApMaxIs)
	{
		//-------------------------------------------------------------------------- 
		//                LAT OPTIONS FOR THREE SCREENS
		//--------------------------------------------------------------------------
		lat_ext1 = GUI.Toggle (Rect (Screen.width/2+20, Screen.height/2+20, 180, 20), lat_ext1, " X-Ray Spine");    
		lat_ext2 = GUI.Toggle (Rect (Screen.width/2+20, Screen.height/2+40, 180, 20), lat_ext2, " Negative");    
		lat_ext3 = GUI.Toggle (Rect (Screen.width/2+20, Screen.height/2+80, 180, 20), lat_ext3, " Bones");    
		lat_ext4 = GUI.Toggle (Rect (Screen.width/2+20, Screen.height/2+100, 180, 20), lat_ext4, " Nerves");    
		GUI.enabled = true;
	}        
}


//==================================== 
//  Camera PAN (dragging)
//====================================
function CamPan (c : Camera)
{
	h = (-1) * Input.GetAxis("Mouse X"); //The horizontal movement - could use "Horizontal"
	v = (-1) * Input.GetAxis("Mouse Y"); //The vertical movement - could use "Vertical"

	if (Input.GetMouseButton(1))
	{		
		c.transform.Translate(Vector3.right * h * hSensitivity); //truck = horizontal movement
		c.transform.Translate(Vector3.up * v * vSensitivity);   //pedestal = vertical movement
	}

}


//================================== 
//     Window Brightess X-RAY
//================================== 
function WinBrightness (windowID : int) 
{    
	GUI.Label(Rect(10, 20, 200, 30), "RIM: ");		// Rim X-RAY
	GUI.Label(Rect(10, 60, 200, 30), "INSIDE: ");	// Inside X-Ray
	
	hSliderRim = GUI.HorizontalSlider (Rect (10, 40, 200, 30), hSliderRim, 0, 2);		// RIM CTRL
	hSliderInside = GUI.HorizontalSlider (Rect (10, 80, 200, 30), hSliderInside, 0, 1);	// INSIDE CTRL
	SpineXraySet (hSliderRim, hSliderInside); // Set X-Ray for spine 
	
	// Button "Reset" 
	if (GUI.Button (Rect (10, 110, 200, 25), "Reset")) 
	{
		hSliderRim = xRim;
		hSliderInside = xInside;
	}

	GUI.DragWindow (Rect (0,0,10000,10000));
}


//================================== 
//         C A M E R A  AP
//================================== 
function ApInit ()		
{
	// Color for Negative AP View
	if (ap_ext2)
		GUI.contentColor = Color.black;
	else	 
		GUI.contentColor = Color.white; 

	//--------------------------------------------------------------------------
	//                             ZOOM(AP)
	//--------------------------------------------------------------------------
	if (!LatMaxIs && !MainMaxIs)
	{
	// ZOOM AP
	GUI.Label(Rect(Screen.width-230, 45, 200, 30), "ZOOM: ");
	hSliderZoom_ap = GUI.HorizontalSlider (Rect (Screen.width-230, 65, 200, 30), hSliderZoom_ap, 15,5);
	cam2.fieldOfView = hSliderZoom_ap; 

	// CONTRAST AP
	GUI.Label(Rect(Screen.width-230, 85, 200, 30), "CONTRAST: ");  
	hSliderContrast_ap = GUI.HorizontalSlider (Rect (Screen.width-230, 105, 200, 30), hSliderContrast_ap, 0, 3);
	CE = cam2.GetComponent("ContrastEnhance"); // Script ContrastEnhance (for camera AP)
	CE.intensity = hSliderContrast_ap;
	}
	
	// Options AP VIEW
	if (ApMaxIs)  
		OptApMax ();					//Options for AP MAX
	else	
		if (!MainMaxIs)
			OptApThreeScreens ();		// Options for three screens 
							
	// X-Ray AP
 	if (ap_ext1) 
	{	
		cam2.cullingMask |= (1 << 13);	// ON Layer "SpineX"
		cam2.cullingMask &= ~(1 << 8);	// OFF Layer "SpineR" 
	}	
	else
	{
		cam2.cullingMask &= ~(1 << 13);	// OFF Layer "SpineX"
		cam2.cullingMask |= (1 << 8);	// ON Layer "SpineR"
	}
	
 	//  Negative AP
 	if (ap_ext2) 
		cam2.GetComponent("GrayscaleEffect").enabled = true;	// AP Nagative = ON
	else
		cam2.GetComponent("GrayscaleEffect").enabled = false;	// AP Nagative = OFF
	
 	//---------------------------------------------------------------------------------
 	// Bones Xray (16,20)
 	if (ap_ext3)
		cam2.cullingMask |= (1 << 20);	// ON Layer "BonesX"
	else
		cam2.cullingMask &= ~(1 << 20);	// ON Layer "BonesX"
	
 	
	//---------------------------------------------------------------------------------
	// Nerves XRay(17,19)
 	if (ap_ext4)
		cam2.cullingMask |= (1 << 19);	// ON Layer "NervesX"
	else
		cam2.cullingMask &= ~(1 << 19);	// ON Layer "NervesX"
		
	//--------------------------------------------------------------------------------- 
	//             Window "BRIGHTNESS SPINE" COMMON OPTIONS (SERVICE)
	//--------------------------------------------------------------------------------- 
	if ((ap_ext2 && ApMaxIs) || (lat_ext2 && LatMaxIs))	// Color for Negaive 
	{	
		GUI.contentColor = Color.black;
		cor_ext = GUI.Toggle (Rect (10, 840, 180, 20), cor_ext, " Brightness X-Ray spine");    
		GUI.contentColor = Color.white;
	}
	else
	{
		GUI.contentColor = Color.green;
		cor_ext = GUI.Toggle (Rect (10, 840, 180, 20), cor_ext, " Brightness X-Ray spine");    
	}	
	
	GUI.enabled = true;        
	
	if(cor_ext) 
		windowRectBrightness = GUI.Window (5, windowRectBrightness, WinBrightness, "Brightness X-Ray spine:");    
	
	GUI.contentColor = Color.white;

}

	
//================================== 
//        C A M E R A  LAT
//================================== 
function LatInit ()
{
	// Color for Negative LAT View
	if (lat_ext2)
		GUI.contentColor = Color.black;
	else	 
		GUI.contentColor = Color.white; 
	
	//-------------------------------------------------------------------------
	//                             ZOOM (LAT)
	//-------------------------------------------------------------------------
	if (!ApMaxIs && !ThreeScreenIs && !MainMaxIs)
	{
	// ZOOM LAT (View LAT) 
	GUI.Label(Rect(Screen.width-230, 45, 200, 30), "ZOOM: ");
	hSliderZoom_lat = GUI.HorizontalSlider (Rect (Screen.width-230, 65, 200, 30), hSliderZoom_lat, 15,5);
	cam3.fieldOfView = hSliderZoom_lat; 

	// CONTRAST LAT (View LAT)
	GUI.Label(Rect(Screen.width-230, 85, 200, 30), "CONTRAST: ");  
	hSliderContrast_lat = GUI.HorizontalSlider (Rect (Screen.width-230, 105, 200, 30), hSliderContrast_lat, 0, 3);
	CE = cam3.GetComponent("ContrastEnhance"); // Script "ContrastEnhance" for camera LAT 
	CE.intensity = hSliderContrast_lat;
	}
	
	if (ThreeScreenIs)	
	{
	// ZOOM LAT (Three Screens) 
	GUI.Label(Rect(Screen.width-230, Screen.height/2+50, 200, 30), "ZOOM: ");
	hSliderZoom_lat = GUI.HorizontalSlider (Rect (Screen.width-230,  Screen.height/2+70, 200, 30), hSliderZoom_lat, 15,5);
	cam3.fieldOfView = hSliderZoom_lat; 

	// CONTRAST LAT (Three Screens)
	GUI.Label(Rect(Screen.width-230,  Screen.height/2+90, 200, 30), "CONTRAST: ");  
	hSliderContrast_lat = GUI.HorizontalSlider (Rect (Screen.width-230,  Screen.height/2+110, 200, 30), hSliderContrast_lat, 0, 3);
	CE = cam3.GetComponent("ContrastEnhance"); // Script "ContrastEnhance" for camera LAT
	CE.intensity = hSliderContrast_lat;
	}

	//-------------------------------------------------------------------------- 
	//                             LAT OPTIONS
	//--------------------------------------------------------------------------
	// Options LAT VIEW
	if (LatMaxIs)  
		OptLatMax ();					//Options for LAT MAX
	else	
		if (!MainMaxIs)
			OptLatThreeScreens ();		// Options for three screens 

 	// X-Ray LAT
 	if (lat_ext1) 
	{	
		cam3.cullingMask |= (1 << 13);	// ON Layer "SpineX"
		cam3.cullingMask &= ~(1 << 8);	// OFF Layer "SpineR"
	}	
	else
	{
		cam3.cullingMask &= ~(1 << 13);	// OFF Layer "SpineX"
		cam3.cullingMask |= (1 << 8);	// ON Layer "SpineR"
	}
 	//---------------------------------------------------------------------------------

 	// Negative LAT
 	if (lat_ext2) 
	{	
		cam3.GetComponent("GrayscaleEffect").enabled = true;	// LAT Nagative = ON
		GUI.contentColor = Color.black;  
	}
	else
	{
		cam3.GetComponent("GrayscaleEffect").enabled = false;	// LAT Nagative = OFF
		GUI.contentColor = Color.white;
	}
	
	// Color for Negative LAT View
	if (lat_ext2)
		GUI.contentColor = Color.white;

	//=====================================================
	//                       ON/OFF
	//=====================================================
 	// Bones Xray (16,20)
 	if (lat_ext3)
		cam3.cullingMask |= (1 << 20);	// ON Layer "BonesX"
	else
		cam3.cullingMask &= ~(1 << 20);	// ON Layer "BonesX"
	
	//------------------------------------------------------
	// Nerves XRay(17,19)
 	if (lat_ext4)
		cam3.cullingMask |= (1 << 19);	// ON Layer "NervesX"
	else
		cam3.cullingMask &= ~(1 << 19);	// ON Layer "NervesX"

	GUI.contentColor = Color.white;       

}


//================================== 
//   C A M E R A S  DRAGING (PAN)
//================================== 
function CamPan ()
{
	// OFFSET XZ (BTN RIGHT MOUSE)
    if (ThreeScreenIs)
    {
		// if PAN for AP view
		if ((Input.mousePosition.x > Screen.width/2) && (Input.mousePosition.y > Screen.height/2))
    	{
    		cam1.GetComponent("maxCamera").enabled = false; // MAIN Camera off
    		CamPan (cam2);	// Dragging AP
   	 	}

		// if PAN for LAT view
    	if ((Input.mousePosition.x > Screen.width/2) && (Input.mousePosition.y < Screen.height/2))
    	{
    		cam1.GetComponent("maxCamera").enabled = false; // MAIN Camera off
    		CamPan (cam3);	// Dragging LAT
    	}

		// if PAN for MAIN view
    	if (Input.mousePosition.x < Screen.width/2) 
    		cam1.GetComponent("maxCamera").enabled = true; 	// MAIN Camera on
    }
    
    // if MAXIMIZE MAIN view
    if (ApMaxIs)
    {
   		cam1.GetComponent("maxCamera").enabled = false; 	// MAIN Camera off
   		CamPan (cam2);	// Dragging AP
    }
   
    // if MAXIMIZE LAT view
    if (LatMaxIs)
    {
   		cam1.GetComponent("maxCamera").enabled = false; 	// MAIN Camera off
   		CamPan (cam3);	// Dragging LAT
    }

}


//================================================== 
//                MIXIMIZE - MINIMIZE 
//================================================== 
function MaxMinViews ()
{
	//-------------------------------- 
	// Button "Maximize/Minimise" AP
	//--------------------------------
	if (!LatMaxIs && !MainMaxIs)
	{
		if (GUI.Button (Rect_AP_Max_Min, "", NAV_WIN_MAX_MIN))
			if (!ApMaxIs)
			{
				ApMaxIs = true;
				ThreeScreenIs = false;
			}	
			else
			{
				ApMaxIs = false;
				ThreeScreenIs = true;
			} 		 

		// Button "RESET VIEW" AP
		if (GUI.Button (Rect_AP_Reset, "", NAV_WIN_RESET_BUTTON)) 
		{
			cam2.transform.localPosition = PosApCam;
			hSliderZoom_ap = 15;
		}
	}

	//--------------------------------- 
	// Button "Maximize/Minimise" LAT
	//--------------------------------- 
	if (!ApMaxIs && !MainMaxIs)
	if (ThreeScreenIs)
	{
		if (GUI.Button (Rect_LAT_Max_Min, "", NAV_WIN_MAX_MIN)) 
		if (!LatMaxIs)
		{
			LatMaxIs = true;
			ThreeScreenIs = false;

		}	
		else
		{
			LatMaxIs = false;
			ThreeScreenIs = true;
		} 		 
			
		// Button "RESET VIEW" LAT
		if (GUI.Button (Rect_LAT_Reset, "", NAV_WIN_RESET_BUTTON)) 
		{
			cam3.transform.localPosition = PosLatCam;
			hSliderZoom_lat = 15;
		}
	} 
	else
	{
		if (GUI.Button (Rect_AP_Max_Min, "", NAV_WIN_MAX_MIN)) 
		if (!LatMaxIs)
		{
			LatMaxIs = true;
			ThreeScreenIs = false;
		}	
		else
		{
			LatMaxIs = false;
			ThreeScreenIs = true;
		} 		 
			
		// Button "RESET VIEW" LAT
		if (GUI.Button (Rect_AP_Reset, "", NAV_WIN_RESET_BUTTON)) 
		{
			cam3.transform.localPosition = PosLatCam;
			hSliderZoom_lat = 15;
		}
	}
	
	// If AP miximize view 
	if (ApMaxIs && !LatMaxIs && !MainMaxIs)
	{
		cam1.GetComponent.<Camera>().active = false;					// MAIN off
   		cam2.enabled = true;						// AP on
   		cam3.enabled = false;						// LAT off
		cam2.rect = new Rect(0, 0, 1, 1);			// AP RECT (full screen)
		ThreeScreenIs = false;
	}

	// If LAT miximize view 
	if (LatMaxIs && !ApMaxIs && !MainMaxIs)
	{
		cam1.GetComponent.<Camera>().active = false;					// MAIN off
   		cam2.enabled = false;						// AP off
   		cam3.enabled = true;						// LAT on
		cam3.rect = new Rect(0, 0, 1, 1);			// LAT RECT  (full screen)
		ThreeScreenIs = false;
	}

	// If Three Screens views 
	if (!ApMaxIs && !LatMaxIs && !MainMaxIs)
	{
		cam1.GetComponent.<Camera>().active = true;					// MAIN on
   		cam2.enabled = true;						// AP on
   		cam3.enabled = true;						// LAT on
		cam1.rect = new Rect(0, 0, 0.5, 1);			// MAIN RECT 
		cam2.rect = new Rect(0.5, 0.5, 1, 0.5);		// AP RECT
		cam3.rect = new Rect(0.5, 0, 0.5, 0.499);	// LAT RECT
		ThreeScreenIs = true;
	}

  	//------------------------------------ 
  	//	BTN MAX/MIN CAMERA MAIN (cam1)
	//------------------------------------
	// If not Maximize MAIN view 
	if (!MainMaxIs)
	{
		Rect_Main = Rect_MainMin;
	}
	// If Maximize MAIN view 
	if (MainMaxIs)
	{
		Rect_Main = Rect_MainMax;
	}
	// If no Maximize AP & LAT views 
	if (!ApMaxIs && !LatMaxIs)
	if (GUI.Button (Rect_Main, "", NAV_WIN_MAX_MIN))
	if (!MainMaxIs)	
	{
		MainMaxIs = true;
	} 
	else
	{
		MainMaxIs = false;
	}

	// If Maximize MAIN views 
	if(MainMaxIs)
	{            
   	 	cam2.enabled = false;	// AP OFF 
   	 	cam3.enabled = false;	// LAT OFF
		cam1.main.rect = new Rect(0, 0, 1, 1); //Set the MAIN camera to full screen
		ThreeScreenIs = false;
		GUI.contentColor = Color.white;   
		GUI.Label (Rect (Screen.width-50, 10, 200, 20), "MAIN");
		GUI.contentColor = Color.white;  
		GUI.Label (Rect (Screen.width-450, Screen.height-25, 500, 20), "Use the navigation camera buttons mouse (Wheel, Middle BTN, Right BTN)");
		
	}	
	
	//------------------------------------------
	//	If no Maximize MAIN & AP & LAT views
	//------------------------------------------ 
	if(!MainMaxIs && !ApMaxIs && !LatMaxIs)
	{
   	 	cam2.enabled = true;	// AP ON 
   	 	cam3.enabled = true; 	// LAT ON
		cam1.main.rect = new Rect(0, 0, 0.5, 1); //Set the MAIN camera to 1/2 screen
		ThreeScreenIs = true;
		GUI.Label (Rect (Screen.width/2-50, 10, 200, 20), "MAIN");

	}	
	//---------------------- Button "Maximize/Minimise" MAIN -----------------------------

}


//================================== 
//     Set X-Ray for spine 
//================================== 
function SpineXraySet (sR : float, sI: float) 
{
	// BRITNESS SPINE (Rim)
	disk_C1_L.GetComponent.<Renderer>().material.SetFloat( "_Rim",sR  );
	disk_C1_R.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_C2.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_C3.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_C4.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_C5.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_C6.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_C7.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	
	disk_L1.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_L2.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_L3.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_L4.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_L5.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );

	disk_T1.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_T2.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_T3.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_T4.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_T5.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_T6.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_T7.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_T8.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_T9.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_T10.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_T11.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	disk_T12.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );

	Vert_C1.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_C2.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_C3.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_C4.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_C5.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_C6.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_C7.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );

	Vert_L1.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_L2.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_L3.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_L4.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_L5.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	
	Vert_T1.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_T2.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_T3.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_T4.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_T5.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_T6.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_T7.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_T8.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_T9.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_T10.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_T11.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	Vert_T12.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );

	sacrum_1.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );
	sacrum_2.GetComponent.<Renderer>().material.SetFloat( "_Rim", sR );

	// CONTRAST SPINE (Inside)
	disk_C1_L.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_C1_R.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_C2.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_C3.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_C4.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_C5.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_C6.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_C7.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );

	disk_L1.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_L2.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_L3.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_L4.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_L5.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );

	disk_T1.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_T2.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_T3.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_T4.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_T5.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_T6.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_T7.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_T8.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_T9.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_T10.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_T11.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	disk_T12.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );

	Vert_C1.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_C2.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_C3.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_C4.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_C5.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_C6.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_C7.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );

	Vert_L1.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_L2.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_L3.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_L4.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_L5.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_T1.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_T2.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_T3.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_T4.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_T5.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_T6.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_T7.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_T8.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_T9.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_T10.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_T11.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	Vert_T12.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );

	sacrum_1.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );
	sacrum_2.GetComponent.<Renderer>().material.SetFloat( "_Inside", sI );

}

/*
disk_C1_L
disk_C1_R
disk_C2
disk_C3
disk_C4
disk_C5
disk_C6
disk_C7

disk_L1
disk_L2
disk_L3
disk_L4
disk_L5

disk_T1
disk_T2
disk_T3
disk_T4
disk_T5
disk_T6
disk_T7
disk_T8
disk_T9
disk_T10
disk_T11
disk_T12

Vert_C1
Vert_C2
Vert_C3
Vert_C4
Vert_C5
Vert_C6
Vert_C7

Vert_L1
Vert_L2
Vert_L3
Vert_L4
Vert_L5
	
Vert_T1
Vert_T2
Vert_T3
Vert_T4
Vert_T5
Vert_T6
Vert_T7
Vert_T8
Vert_T9
Vert_T10
Vert_T11
Vert_T12

sacrum_1
sacrum_2
*/
