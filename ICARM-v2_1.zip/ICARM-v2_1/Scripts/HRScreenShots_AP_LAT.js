//**********************************************************
// HRScreenShots_AP_LAT.js
// Save image from camera screenshot.
//
// Writing Sergey Gasanov (sgiman), 28.11.2013-03.12.2013
//**********************************************************
// Saves screenshot to System folder
import System.IO;
import System;


var guiSkin: GUISkin;

//var resWidth : int = 2000;     			//   X size pix
//var resHeight : int = 2000;    			//   Y size pix

var ResX : String = "1500";
var ResY : String = "1500";


// Cameras
var cam1 : Camera; // AP
var cam2 : Camera; // LAT 

private var takeHiResShot : boolean = false; 	//  Flag Save Screenshot
     

//=======================
//       OnGUI
//=======================
function OnGUI()
{

	GUI.skin = guiSkin;
	GUI.contentColor = Color.yellow;

	GUI.Label(Rect(785, Screen.height-105, 70, 20), "X Res: ");
	GUI.Label(Rect(865, Screen.height-105, 70, 20), "Y Res: ");

	ResX = GUI.TextField (Rect (785, Screen.height-85, 70, 20), ResX, 25);
	ResY = GUI.TextField (Rect (865, Screen.height-85, 70, 20), ResY, 25);
	
	GUI.contentColor = Color.white;

	//---------------- Button SAVE AP/LAT ----------------- 
	if (GUI.Button(new Rect(785, Screen.height-60, 150, 50), "SAVE AP / LAT"))
    {
       	//print("Sucess!");
        takeHiResShot = true;
    }
    else
      	takeHiResShot = false;


}
                  
     
//==============================
//          LateUpdate
//==============================
function LateUpdate ()
{
             		 		
	// Save camera screenshot 
	if (takeHiResShot) 
	{
		resWidth = parseInt(ResX);   
		resHeight = parseInt(ResX);
		 
		//-----------------------
		//  SAVE SCREESHOT AP
		//----------------------- 
		var rt_ap : RenderTexture= new RenderTexture(resWidth, resHeight, 24, RenderTextureFormat.ARGB32);
    	rt_ap.filterMode = FilterMode.Trilinear;
    	cam1.GetComponent.<Camera>().targetTexture = rt_ap;
    		
		var screenShot_ap : Texture2D = new Texture2D(resWidth, resHeight, TextureFormat.RGB24, false);
    	cam1.GetComponent.<Camera>().Render();
    	
		RenderTexture.active = rt_ap;
    	//RenderTexture.antiAliasing = 8; 		
    	screenShot_ap.ReadPixels(new Rect(0, 0, resWidth, resHeight), 0, 0);
    	cam1.GetComponent.<Camera>().targetTexture = null;
    		
		RenderTexture.active = null; // JC: added to avoid errors
    	Destroy(rt_ap);
    		
		var bytes_ap : byte[] = screenShot_ap.EncodeToPNG();
    	var filename_ap : String = Application.dataPath + "/screenshots/carm_AP.png";
    	System.IO.File.WriteAllBytes(filename_ap, bytes_ap);

		//-----------------------
		//  SAVE SCREESHOT LAT
		//----------------------- 
		var rt_lat : RenderTexture = new RenderTexture(resWidth, resHeight, 24, RenderTextureFormat.ARGB32);
    	rt_lat.filterMode = FilterMode.Trilinear;
    	cam2.GetComponent.<Camera>().targetTexture = rt_lat;
    		
		var screenShot_lat : Texture2D= new Texture2D(resWidth, resHeight, TextureFormat.RGB24, false);
    	cam2.GetComponent.<Camera>().Render();
    	
    	//RenderTexture.antiAliasing = 8;		
		RenderTexture.active = rt_lat;
    	screenShot_lat.ReadPixels(new Rect(0, 0, resWidth, resHeight), 0, 0);
    	cam2.GetComponent.<Camera>().targetTexture = null;
    		
		RenderTexture.active = null; // JC: added to avoid errors
    	Destroy(rt_lat);
    		
		var bytes_lat : byte[] = screenShot_lat.EncodeToPNG();
    	var filename_lat : String = Application.dataPath + "/screenshots/carm_LAT.png";
    	System.IO.File.WriteAllBytes(filename_lat, bytes_lat);
 	
    	    				
		Debug.Log(String.Format("Took screenshot to: {0}", filename_ap));   		
		Debug.Log(String.Format("Took screenshot to: {0}", filename_lat));   		
		takeHiResShot = false;
	 }
  
}

